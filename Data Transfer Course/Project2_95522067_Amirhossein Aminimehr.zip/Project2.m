clc
clear
% Create WAV file in current folder .
load handel.mat
audiowrite('audio.wav',y,Fs)
clear y Fs
% Read the data back into MATLAB , and listen to audio .
[y, Fs] = audioread('audio.wav');
% Play wav file
player = audioplayer(y,Fs);
play(player);

%Description about y and Fs
%double is a 64 bit IEEE 754 double precision Floating Point Number (1 bit for the sign,
%11 bits for the exponent, and 52* bits for the value), i.e. double has 15 decimal digits
%of precision.
whos y;
whos Fs;

%Total audio time
TotalTime = length(y)/Fs;

%Histogram
[counts,binCenters] = audioread('audio.wav');
[counts,binCenters] = hist(y, Fs);
histogram(y, 'FaceColor', 'blue');
grid on;

%Entropy
n = hist(y,length(y));
prob = n / sum(n);
prob0 = prob(prob~=0);
entropy = -sum(prob0 .*log2(prob0));

%Limit audio compression KBytes
limitKByte = (entropy * length(y))/(8*1024);

%New file format with low volume
audiowrite('audio.ogg',y,Fs)
audiowrite('audio.oga',y,Fs)

%Huffman
symbols = [1:125];
dict = huffmandict(symbols ,prob0) ;
sig = randsrc(100,1,[symbols;prob0]);
comp = huffmanenco(sig,dict);

huaffmanSize=[];
flag = 0;
for i = 1:125
    flag = 0;
    dict{i,2};
    x = ans;
    for j = 1:length(x)
        if x(1,j) == x(1,j)
            z = length(x)-j+1;
            huaffmanSize = [huaffmanSize ; z];
            flag = 1;
            break
        end
    end
    if flag == 0
        huaffmanSize = [huaffmanSize ; 1];
    end
end

sum = 0;
for i = 1:125
    sum = sum + (prob0(i)*huaffmanSize(i));
end

%Limit audio compression with hauffman encoding in KiloByte
LimitKByteHauffman = (sum*length(y))/(1024*8);

%Transfer Time in second
TransferTime = LimitKByteHauffman/(64/8);
