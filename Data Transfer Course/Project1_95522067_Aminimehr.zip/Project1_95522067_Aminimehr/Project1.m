%read RGB image
RGB = imread('Lampard.jpg');
imwrite(RGB,'RGBPic.png');

%convert to gray-scale 8 bit
Gray = rgb2gray(RGB);
imwrite(Gray,'GrayPic.png');

%compute enery of image
energy = sum(Gray(:));

%make gaussian noise in image
noiseGray = imnoise(Gray,'gaussian',0,0.01);
imwrite(noiseGray,'noiseGrayPic.png');

%compute SNR of gray-scale image
img=double(Gray(:));
ima=max(img(:));
imi=min(img(:));
mse=std(img(:));
graySNR=10*log10((ima-imi)./mse);

%compute SNR of noised gray-scale image
img=double(noiseGray(:));
ima=max(img(:));
imi=min(img(:));
mse=std(img(:));
noiseGraySNR=10*log10((ima-imi)./mse);

%Frequency domain
ft = fftshift(log(abs(fft2(noiseGray))));


%denoised image with conv2 (this filter was forth best filter)
denoisedconv2 = conv2(double(noiseGray), ones(3)/9, 'same');
denoisedconv2 = uint8(denoisedconv2);
imwrite(denoisedconv2,'DenoisedConv2.png');

%denoised image with gaussian filter (this filter was third best filter)
g=fspecial('gaussian',[5 5],2);
denoisedgaussian=imfilter(noiseGray,g,'same');
imwrite(denoisedgaussian,'DenoisedGaussian.png');

%denoised image with wiener2 filter (this filter was second best filter)
denoisedwiener2 = wiener2(noiseGray,[5 5]);
imwrite(denoisedwiener2,'DenoisedWiener2.png');

%denoised image with median filter (this filter was fifth best filter)
denoisedmedian = medfilt2(noiseGray);
imwrite(denoisedmedian,'DenoisedMedian.png');

%denoised image with imnlm filter (this filter was the best)
denoisedimnlm = imnlmfilt(noiseGray)
imwrite(denoisedimnlm,'DenoisedImnlm.png');

%peaksnr
peaksnr1 = psnr(Gray ,denoisedimnlm) %First Best Filter (~32)
peaksnr2 = psnr(Gray ,denoisedwiener2) %Second Best Filter (~30)
peaksnr3 = psnr(Gray ,denoisedgaussian) %Third Best Filter (~29)
peaksnr4 = psnr(Gray ,denoisedconv2) %Forth Best Filter (~28)
peaksnr5 = psnr(Gray ,denoisedmedian) %Fifth Best Filter (~27)

%show images
set(gcf,'Position',get(0,'Screensize'));
subplot(2,9,1),imshow(RGB),title('Original Image');
subplot(2,9,2),imshow(Gray),title('Gray Scale Image');
subplot(2,9,3),imshow(noiseGray),title('Noised Image');
subplot(2,9,4),imshow(ft, []),title('Frequency domain');
subplot(1,9,5),imshow(denoisedimnlm),title('output of imnlm filter');
subplot(1,9,6),imshow(denoisedconv2),title('output of conv2 filter');
subplot(1,9,7),imshow(denoisedgaussian),title('output of gaussian filter');
subplot(1,9,8),imshow(denoisedwiener2),title('output of wiener2 filter');
subplot(1,9,9),imshow(denoisedmedian),title('output of median filter');