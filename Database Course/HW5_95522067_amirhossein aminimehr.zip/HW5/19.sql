SELECT a.first_name, a.Salary, a.Department
FROM worker a
JOIN (SELECT MAX(Salary) As Highest, department FROM worker GROUP BY department) b
ON a.Department = b.Department and a.Salary = b.Highest