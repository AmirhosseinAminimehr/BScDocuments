SELECT department, sum(round(salary/12,2)) FROM worker group by department
   