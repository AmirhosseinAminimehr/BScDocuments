select *
from worker
where worker_id in
(select worker_id
from worker
order by salary desc
limit 6)

