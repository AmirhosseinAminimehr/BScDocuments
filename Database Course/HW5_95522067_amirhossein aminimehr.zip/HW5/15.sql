SELECT salary 
FROM worker Emp1
WHERE (3) = ( /* n-1 bejaye 3 mitavan gozasht */
SELECT COUNT(DISTINCT(Emp2.Salary))
FROM worker Emp2
WHERE Emp2.Salary > Emp1.Salary)