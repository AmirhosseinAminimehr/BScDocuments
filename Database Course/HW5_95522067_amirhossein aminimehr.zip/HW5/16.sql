SELECT wk.*
FROM worker wk 
CROSS JOIN ( VALUES (1), (2) ) tb (id) ;