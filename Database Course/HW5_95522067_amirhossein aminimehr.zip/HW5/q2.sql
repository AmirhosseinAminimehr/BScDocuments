CREATE PROCEDURE dbo.terms 
       @worker_id                      integer  = NULL   , 
       @first_name                   NVARCHAR(50)      = NULL   , 
       @last_name                       NVARCHAR(50)  = NULL   , 
       @salary               integer  = NULL ,
	   @joining_date              date  = NULL  ,
	   @department              NVARCHAR(50)  = NULL  
AS 
BEGIN 
     SET NOCOUNT ON 

     INSERT INTO dbo.terms
          (                    
                     worker_id  ,                    
       				first_name ,                 
       				last_name ,                     
       				salary   ,           
	   				joining_date  ,           
	  				 department                  
          ) 
     VALUES 
          ( 
       @worker_id                       , 
       @first_name                    , 
       @last_name                        , 
       @salary               ,
	   @joining_date             ,
	   @department             
          ) 

END 

GO