select concat(first_name,' ',last_name) as complete_name from worker
