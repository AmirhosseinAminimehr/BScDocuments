select  *
From
	worker
Order By worker_id Desc
limit 3