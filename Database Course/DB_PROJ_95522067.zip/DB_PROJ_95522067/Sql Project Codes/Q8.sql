select registered_id,registered_user,count(reserved_ticket_id)
from   registered  join reserved_ticket on(registered_id = user_id)
where registered_id in (select user_id from userr)
group by (registered_id,registered_user)
order by count(reserved_ticket_id)
desc