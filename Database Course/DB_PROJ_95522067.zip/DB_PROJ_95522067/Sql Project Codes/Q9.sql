select director_id,director_name,codirector_name,film_name
from director natural join film
order by director_id