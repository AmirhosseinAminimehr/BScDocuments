insert into hall values (001,001,30,'high tech',4,500);
insert into hall values (001,002,100,'high tech2',5,600);
insert into hall values (001,003,70,'high tech',4,700);
insert into hall values (002,001,80,'high tech2',5,300);
insert into hall values (003,001,90,'high tech',8,200);
insert into hall values (004,001,400,'high tech',20,900);
insert into hall values (005,001,30,'high tech2',3,100);
insert into hall values (006,001,35,'high tech2',4,100);
