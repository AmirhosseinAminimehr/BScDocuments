select cinema_id,cinema_name,count(cinema_id)
from cinema natural join hall
group by (cinema_id,cinema_name)
order by (cinema_id,cinema_name)