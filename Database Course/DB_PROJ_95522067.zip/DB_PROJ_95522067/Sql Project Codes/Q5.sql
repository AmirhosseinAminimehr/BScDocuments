create temporary table DA as
select * 
from actor natural join film_actor natural join film natural join director;

create function get_actor_director(directorr name)
  returns table(count DA )
as
$$
select *
from actor natural join film_actor natural join film natural join director
where director_name = directorr

$$
language sql;

select director_name,actor_name
from get_actor_director('tarantino')
group by (director_name,actor_name);
