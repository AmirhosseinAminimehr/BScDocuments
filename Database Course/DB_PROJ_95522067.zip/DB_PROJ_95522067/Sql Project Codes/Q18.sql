CREATE TABLE director_edits (
   director_id integer PRIMARY KEY,
   director_name VARCHAR(20) NOT NULL,
   director_point_100 integer not null,
   changed_on TIMESTAMP(6) NOT NULL
);


CREATE OR REPLACE FUNCTION log_last_director_changes1()
  RETURNS trigger AS
$BODY$
BEGIN
   IF NEW.* <> OLD.* THEN
       INSERT INTO director_edits
       VALUES(new.director_id,new.director_name,old.director_point_100,now());
   END IF;
 
   RETURN NEW;
END;
$BODY$
language PLPGSQL;

CREATE TRIGGER director_changes1
  BEFORE UPDATE
  ON director
  FOR EACH ROW
  EXECUTE PROCEDURE log_last_director_changes1();
  
  
select * from director

delete from director_edits where director_id = 99



update  director
set director_name = 'torkashvandd'
where director_name = 'ostadtorkashvand'


select * from director
select * from director_edits