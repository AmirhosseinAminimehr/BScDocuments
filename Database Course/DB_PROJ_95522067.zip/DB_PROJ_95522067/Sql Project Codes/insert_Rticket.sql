insert into reserved_ticket values (002,002,001,001,001,005,'2019/01/01');
insert into reserved_ticket values (002,001,001,002,001,005,'2019/09/01');
insert into reserved_ticket values (001,001,001,001,005,006,'2019/02/01');
insert into reserved_ticket values (001,001,001,003,001,007,'2019/08/01');
