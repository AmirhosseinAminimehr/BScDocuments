insert into adminn values (001,001);
insert into adminn values (002,002);
insert into adminn values (003,003);
insert into adminn values (004,001);

