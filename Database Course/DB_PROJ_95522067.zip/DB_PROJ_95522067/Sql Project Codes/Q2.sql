create temporary table AFA as
select * 
from actor natural join film_actor natural join film;

create function get_actor_movie(movie name)
  returns table(count AFA )
as
$$
select *
from actor natural join film_actor natural join film
where film_name = movie
order by actor_point_100
desc;
$$
language sql;




select actor_name,actor_point_100
from get_actor_movie('once apon a time in hollywood');