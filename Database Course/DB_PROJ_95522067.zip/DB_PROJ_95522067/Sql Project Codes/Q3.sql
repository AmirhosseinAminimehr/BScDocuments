create temporary table CH as
select * 
from hall natural join cinema ;

create function get_cinema_hall(cinemaN name)
  returns table(count CH )
as
$$
select *
from hall natural join cinema
where cinema_name = cinemaN
order by seat_number
desc;
$$
language sql;

select cinema_name,hall_id,seat_number
from get_cinema_hall('ofoq');
