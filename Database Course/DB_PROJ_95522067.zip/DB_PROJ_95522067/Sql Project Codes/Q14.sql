create temporary table SC2 as
select * 
from sessionn natural join cinema;

create function get_cinema_session(cinemaName name)
  returns table(count SC2 )
as
$$
select *
from sessionn natural join cinema
where cinema_name = cinemaName
$$
language sql;

select cinema_name,session_id,session_start_time,session_finish_time,session_language
from get_cinema_session('ofoq');

