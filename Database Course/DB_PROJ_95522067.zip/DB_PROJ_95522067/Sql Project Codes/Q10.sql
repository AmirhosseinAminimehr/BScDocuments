select registered_id,registered_user,count(*)
from registered join ticket on(admin_id=registered_id)
group by (registered_id)
order by count(*)
desc