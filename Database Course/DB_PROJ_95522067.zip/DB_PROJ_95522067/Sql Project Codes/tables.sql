create table cinema 
(
cinema_id integer not null unique,
address varchar(300) not null unique,
cinema_name name not null unique,
cinema_phone varchar(20) not null unique,
primary key(cinema_id)
);

create table hall 
(
cinema_id integer not null , 
hall_id integer not null ,
hall_name varchar(20) not null,
seat_number integer not null,
sound_system varchar(30) not null,
screen_size_m2 integer not null ,
hall_size_m2 integer not null,
foreign key (cinema_id) references cinema(cinema_id) on delete cascade on update cascade,
primary key(cinema_id,hall_id)
);


create table sessionn
(
cinema_id integer not null , 
session_id integer not null,
session_language varchar(30) not null,
session_start_time date not null ,
session_finish_time date not null,
foreign key (cinema_id) references cinema(cinema_id) on delete cascade on update cascade,
primary key(cinema_id,session_id)
);

create table director
(
director_id integer not null unique,
director_name varchar(20) not null,
director_point_100 integer not null,
primary key(director_id)
);

create table actor
(
actor_id integer not null unique,
actor_birthday date not null,
actor_name varchar(20) not null,
primary key(actor_id)
);


create table film
(
film_id integer not null unique,
film_name varchar(30) not null unique,
genre varchar(20) not null ,
age integer not null,
biuld_date date not null,
director_id integer not null references director(director_id),
codirector_name varchar(20) not null,
primary key(film_id)
);


create table registered
(
registered_id integer not null unique,
registered_email varchar(50) not null unique,
registered_phone varchar(20) not null unique,
registered_user varchar(30) not null unique,	
registered_password varchar(30) not null,
cinema_id integer not null references cinema(cinema_id),
primary key(registered_id)
);



create table adminn
(
admin_id integer not null unique,
foreign key (admin_id) references registered(registered_id) on delete cascade on update cascade,
cinema_id integer not null references cinema(cinema_id),
primary key(admin_id)
);


create table userr
(
user_id integer not null unique,
foreign key (user_id) references registered(registered_id) on delete cascade on update cascade,
primary key(user_id)
);



create table ticket
(
ticket_id integer not null,
hall_id integer not null ,
cinema_id integer not null ,
session_id integer not null ,
film_id integer not null ,
ticket_price_t integer not null,
seat_number integer not null,
admin_id integer not null references adminn(admin_id),
foreign key (cinema_id,hall_id) references hall(cinema_id,hall_id) on delete cascade on update cascade,
foreign key (cinema_id) references cinema(cinema_id) on delete cascade on update cascade,
foreign key (cinema_id,session_id) references sessionn(cinema_id,session_id) on delete cascade on update cascade,
foreign key (film_id) references film(film_id) on delete cascade on update cascade,
primary key(ticket_id,hall_id,cinema_id,session_id,film_id)
);



create table unreserved_ticket
(
unreserved_ticket_id integer not null,
Uhall_id integer not null ,
Ucinema_id integer not null ,
Usession_id integer not null ,
Ufilm_id integer not null ,
foreign key (unreserved_ticket_id,Uhall_id,Ucinema_id,Usession_id,Ufilm_id) references ticket(ticket_id,hall_id,cinema_id,session_id,film_id) on delete cascade on update cascade,
primary key(unreserved_ticket_id,Uhall_id,Ucinema_id,Usession_id,Ufilm_id)
);

create table reserved_ticket
(
reserved_ticket_id integer not null,
Rhall_id integer not null ,
Rcinema_id integer not null ,
Rsession_id integer not null ,
Rfilm_id integer not null ,	
user_id integer not null ,
reservation_date date,
foreign key (reserved_ticket_id,Rhall_id,Rcinema_id,Rsession_id,Rfilm_id) references ticket(ticket_id,hall_id,cinema_id,session_id,film_id) on delete cascade on update cascade,
foreign key (user_id) references userr(user_id) on delete cascade on update cascade,
primary key(reserved_ticket_id,Rhall_id,Rcinema_id,Rsession_id,Rfilm_id)
);






Create table film_actor
(
Actor_id integer not null  references actor(actor_id),
Film_id integer not null references film(film_id),
Character_name varchar(30) not null,
Actor_point_100 integer not null,
Primary key(actor_id,film_id)
);



