insert into registered values (001,'snoop@gmail.com','09555555555','snoop','123');
insert into registered values (002,'dogg@gmail.com','09335555555','dogg','1233');
insert into registered values (003,'hach@gmail.com','09445555555','hach','1233');
insert into registered values (004,'ali@gmail.com','09365555555','ali','1234');
insert into registered values (005,'bunny@gmail.com','09125555555','bunny','1235');
insert into registered values (006,'sani@gmail.com','09385555555','sani','1236');
insert into registered values (007,'hossein@gmail.com','09395555555','hossein','1237');
insert into registered values (008,'qolam@gmail.com','09845555555','qolam','1238');