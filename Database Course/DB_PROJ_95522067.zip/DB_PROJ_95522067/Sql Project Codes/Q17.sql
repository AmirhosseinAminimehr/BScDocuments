CREATE TABLE actor_edits (
   actor_id integer PRIMARY KEY,
   actor_birthday date NOT NULL,
   actor_name VARCHAR(20) NOT NULL,
   changed_on TIMESTAMP(6) NOT NULL
);


CREATE OR REPLACE FUNCTION log_last_actor_changes()
  RETURNS trigger AS
$BODY$
BEGIN
   IF NEW.* <> OLD.* THEN
       INSERT INTO actor_edits
       VALUES(OLD.actor_id,OLD.actor_birthday,old.actor_name,now());
   END IF;
 
   RETURN NEW;
END;
$BODY$
language PLPGSQL;

CREATE TRIGGER actor_changes
  BEFORE UPDATE
  ON actor
  FOR EACH ROW
  EXECUTE PROCEDURE log_last_actor_changes();
  
  
select * from actor

update  actor
set actor_name = 'pittt'
where actor_name = 'pitt'

select * from actor_edits