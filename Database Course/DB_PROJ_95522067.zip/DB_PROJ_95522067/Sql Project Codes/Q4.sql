select actor_name,avg(actor_point_100)
from actor natural join film_actor
group by actor_name
order by avg(actor_point_100)
desc

