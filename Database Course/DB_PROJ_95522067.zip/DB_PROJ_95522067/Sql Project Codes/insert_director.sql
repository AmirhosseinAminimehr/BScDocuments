insert into director values (001,'tarantino',97);
insert into director values (002,'nolan',80);
insert into director values (003,'fincher',90);
insert into director values (004,'snoop dogg',100);
insert into director values (005,'ataran',07);