create temporary table SCA as
select * 
from ticket natural join cinema;

create function get_ticket_session_all(sessionNUM integer,cinemaName name)
  returns table(count SCA )
as
$$
select *
from ticket natural join cinema
where session_id = sessionNUM and cinema_name = cinemaName
$$
language sql;

select cinema_name,session_id,count(*)
from get_ticket_session_all(1,'ofoq')
group by (cinema_name,session_id)
order by count(*)
desc;
