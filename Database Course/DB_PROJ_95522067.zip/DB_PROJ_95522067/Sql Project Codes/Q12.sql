select film_id,film_name,count(*)
from film join reserved_ticket on (film_id=rfilm_id)
group by film_id
order by count(*)
desc