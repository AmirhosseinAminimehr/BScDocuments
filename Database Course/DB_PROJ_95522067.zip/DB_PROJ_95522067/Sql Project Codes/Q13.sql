select actor_id,actor_name,count(*)
from actor natural join film_actor
group by actor_id
order by count(*)
desc
