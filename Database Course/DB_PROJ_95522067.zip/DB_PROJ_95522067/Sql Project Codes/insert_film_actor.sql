insert into film_actor values (001,001,'snoop man',100);
insert into film_actor values (001,004,'super man',91 );
insert into film_actor values (003,001,'bat man',75 );
insert into film_actor values (001,002,'logan',99 );
insert into film_actor values (005,001,'thor',97 );
insert into film_actor values (002,003,'spider man',91 );
insert into film_actor values (001,007,'hulk',83 );
insert into film_actor values (006,001,'asghar',49 );
insert into film_actor values (007,003,'iron man',89 );
insert into film_actor values (007,002,'captain america',72 );
insert into film_actor values (002,001,'heshmat',20 );
insert into film_actor values (007,001,'aber piade 2',8);







