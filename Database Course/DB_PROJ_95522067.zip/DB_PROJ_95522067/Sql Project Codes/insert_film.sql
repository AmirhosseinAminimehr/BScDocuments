insert into film values (001,'once apon a time in hollywood','action',20,'2019/01/01',001,'tara');
insert into film values (002,'batman begins','action',20,'2018/08/01',002,'tara2');
insert into film values (003,'batman dark knight','action',20,'2017/03/01',002,'tara3');
insert into film values (004,'kill bill','action',20,'1999/11/01',001,'tara4');
insert into film values (005,'who am i','action',20,'2002/11/05',003,'tara5');
insert into film values (006,'film maskhare','action',20,'2005/12/01',005,'tara6');
insert into film values (007,'once apon a time in 021','action',20,'1888/10/01',004,'tara7');
