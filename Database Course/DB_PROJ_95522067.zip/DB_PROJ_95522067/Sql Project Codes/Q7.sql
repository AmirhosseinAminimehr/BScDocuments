create temporary table SC as
select * 
from reserved_ticket natural join cinema;

create function get_ticket_session(sessionNUM integer,cinemaName name)
  returns table(count SC )
as
$$
select *
from reserved_ticket natural join cinema
where rsession_id = sessionNUM and cinema_name = cinemaName
$$
language sql;

select cinema_name,rsession_id,count(*)
from get_ticket_session(1,'ofoq')
group by (cinema_name,rsession_id)
order by count(*)
desc;
