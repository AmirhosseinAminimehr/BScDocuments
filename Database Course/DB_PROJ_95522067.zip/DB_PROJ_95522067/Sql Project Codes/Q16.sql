CREATE PROCEDURE insert_actor(actorName name,birth date,actorID integer)
LANGUAGE SQL
AS $$
INSERT INTO actor VALUES (actorID,birth,actorName);
$$;

CALL insert_actor('miller','1978/3/7',15);

