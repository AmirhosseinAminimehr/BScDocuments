import tkinter as tk
import PIL
from PIL import ImageTk
from PIL import Image
import psycopg2


LARGE_FONT= ("Verdana", 12)


class SeaofBTCapp(tk.Tk):

    def __init__(self, *args, **kwargs):
        
        tk.Tk.__init__(self, *args, **kwargs)
        container = tk.Frame(self)

        container.pack(side="top", fill="both", expand = True)

        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}

        for F in (StartPage, actor_insert, director_insert , cinema_insert , user_insert , admin_insert , hall_insert , session_insert ,  film_insert , unreserved_ticket_insert , reserved_ticket_insert , query , q1 , q2 , q3 , q4 , q5 , q6 , q7 , q8 , q9 , q10 , q11 , q12 , q13 , q14 , q15 , q17 , q18):

            frame = F(container, self)

            self.frames[F] = frame

            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame(StartPage)

    def show_frame(self, cont):

        frame = self.frames[cont]
        frame.tkraise()

        
class StartPage(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="Start Page", font=LARGE_FONT)
        label.pack(pady=10,padx=10)

        actor = tk.Button(self, width = 45, text="actor",
                            command=lambda: controller.show_frame(actor_insert))
        actor.pack()

        director = tk.Button(self, width = 45, text="director",
                            command=lambda: controller.show_frame(director_insert))
        director.pack()

        cinema = tk.Button(self, width = 45, text="cinema",
                            command=lambda: controller.show_frame(cinema_insert))
        cinema.pack()

        admin = tk.Button(self, width = 45, text="admin",
                            command=lambda: controller.show_frame(admin_insert))
        admin.pack()

        user = tk.Button(self, width = 45, text="user",
                            command=lambda: controller.show_frame(user_insert))
        user.pack()

        hall = tk.Button(self, width = 45, text="hall",
                            command=lambda: controller.show_frame(hall_insert))
        hall.pack()

        session = tk.Button(self, width = 45, text="session",
                            command=lambda: controller.show_frame(session_insert))
        session.pack()

        film = tk.Button(self, width = 45, text="film",
                            command=lambda: controller.show_frame(film_insert))
        film.pack()

        unreserved_ticket = tk.Button(self, width = 45, text="unreserved ticket",
                            command=lambda: controller.show_frame(unreserved_ticket_insert))
        unreserved_ticket.pack()

        reserved_ticket = tk.Button(self, width = 45, text="reserved ticket",
                            command=lambda: controller.show_frame(reserved_ticket_insert))
        reserved_ticket.pack()


        query1 = tk.Button(self, width = 45, text="queries",
                            command=lambda: controller.show_frame(query))
        query1.pack()

        

        

        


class actor_insert(tk.Frame):
    
    query_label = ""
        
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Insert Actor", font=LARGE_FONT)
        label.grid(row=1, column=2, padx=10,pady=10)


        label = tk.Label(self, text="Delete Actor", font=LARGE_FONT)
        label.grid(row=5, column=2, padx=10,pady=10)

        self.actor_id_field = tk.Entry(self, width=30)
        self.actor_id_field.grid(row=2, column=2, padx=10)
        actor_id_field_label = tk.Label(self, text = "Enter Your Actor ID")
        actor_id_field_label.grid(row=2, column=1)

        self.actor_name_field = tk.Entry(self, width=30)
        self.actor_name_field.grid(row=3, column=2, padx=10)
        actor_name_field_label = tk.Label(self, text = "Enter Your Actor Name")
        actor_name_field_label.grid(row=3, column=1)

        self.actor_birthday_field = tk.Entry(self, width=30)
        self.actor_birthday_field.grid(row=4, column=2, padx=10)
        actor_birthday_field_label = tk.Label(self, text = "Enter Your Actor Birthday")
        actor_birthday_field_label.grid(row=4, column=1)


        self.actor_delete_field = tk.Entry(self, width=30)
        self.actor_delete_field.grid(row=6, column=2, padx=10)
        actor_delete_label = tk.Label(self, text = "Enter Your Actor ID you want to delete")
        actor_delete_label.grid(row=6, column=1)        


        button1 = tk.Button(self,height = 1, width = 20, text="Back to Home",
                            command=lambda: controller.show_frame(StartPage))
        button1.grid(row=2, column=3,pady=0,padx=1)

        submit_btn = tk.Button(self,height = 1, width = 20 , text="add record to database",command=self.submit)
        submit_btn.grid(row=3,column=3,padx=1, pady=0)

        delete_btn = tk.Button(self,height = 1, width = 20 , text="delete",command=self.delete)
        delete_btn.grid(row=6,column=3,padx=1, pady=0)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()


        c.execute("SELECT * from actor")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
    
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=13, column=2,padx=0, pady=60)
        

        #query_label.after(10000 , lambda: query_label.destroy())
    

        
        conn.commit()
        conn.close()
        

    def submit(self):
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        actor_n = self.actor_name_field.get()
        actor_i = self.actor_id_field.get()
        actor_b = self.actor_birthday_field.get()
        #self.query_label.after(1 , lambda: self.query_label.pack_forget())
        #self.query_label.config(state="disabled")
        self.query_label.grid_forget()
        # insert into table
        c.execute("INSERT INTO actor VALUES" + "(" + actor_i + ",'" + actor_b + "','" + actor_n + "')")
    
        c.execute("SELECT * from actor")
        rows = c.fetchall()
        print_rows1 = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows1 = print_rows1 + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows1 = print_rows1 + "\n"
        
        print(print_rows1)
        query_label = tk.Label(self, text=print_rows1)
        
        self.query_label = query_label
        self.query_label.grid(row=13, column=2,padx=0, pady=60)


        conn.commit()
        conn.close()
        

        #clear the text Boxes
        self.actor_id_field.delete(0, tk.END)
        self.actor_name_field.delete(0, tk.END)
        self.actor_birthday_field.delete(0, tk.END)
       


    def delete(self):
        
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        actor_d = self.actor_delete_field.get()
        self.query_label.grid_forget()
        
        # insert into table
        c.execute("Delete from actor where actor_id = " + actor_d )
        
        c.execute("SELECT * from actor")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
        
        conn.commit()
        conn.close()
        
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=13, column=2,padx=0, pady=60)
        
        #clear the text Boxes
        self.actor_delete_field.delete(0, tk.END)
        



class director_insert(tk.Frame):
    
    query_label = ""
        
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Insert Director", font=LARGE_FONT)
        label.grid(row=1, column=2, padx=10,pady=10)


        label = tk.Label(self, text="Delete Director", font=LARGE_FONT)
        label.grid(row=5, column=2, padx=10,pady=10)

        self.director_id_field = tk.Entry(self, width=30)
        self.director_id_field.grid(row=2, column=2, padx=10)
        director_id_field_label = tk.Label(self, text = "Enter Your Director ID")
        director_id_field_label.grid(row=2, column=1)

        self.director_name_field = tk.Entry(self, width=30)
        self.director_name_field.grid(row=3, column=2, padx=10)
        director_name_field_label = tk.Label(self, text = "Enter Your Director Name")
        director_name_field_label.grid(row=3, column=1)

        self.director_point_field = tk.Entry(self, width=30)
        self.director_point_field.grid(row=4, column=2, padx=10)
        director_point_field_label = tk.Label(self, text = "Enter Your Director Point")
        director_point_field_label.grid(row=4, column=1)


        self.director_delete_field = tk.Entry(self, width=30)
        self.director_delete_field.grid(row=6, column=2, padx=10)
        director_delete_label = tk.Label(self, text = "Enter Your Actor ID you want to delete")
        director_delete_label.grid(row=6, column=1)        


        button1 = tk.Button(self,height = 1, width = 20, text="Back to Home",
                            command=lambda: controller.show_frame(StartPage))
        button1.grid(row=2, column=3,pady=0,padx=1)

        submit_btn = tk.Button(self,height = 1, width = 20 , text="add record to database",command=self.submit)
        submit_btn.grid(row=3,column=3,padx=1, pady=0)

        delete_btn = tk.Button(self,height = 1, width = 20 , text="delete",command=self.delete)
        delete_btn.grid(row=6,column=3,padx=1, pady=0)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()


        c.execute("SELECT * from director")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
    
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=13, column=2,padx=0, pady=60)
        

        #query_label.after(10000 , lambda: query_label.destroy())
    

        
        conn.commit()
        conn.close()
        

    def submit(self):
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        director_n = self.director_name_field.get()
        director_i = self.director_id_field.get()
        director_p = self.director_point_field.get()
        #self.query_label.after(1 , lambda: self.query_label.pack_forget())
        #self.query_label.config(state="disabled")
        self.query_label.grid_forget()
        # insert into table
        c.execute("INSERT INTO director VALUES" + "(" + director_i + ",'" + director_n + "'," + director_p + ")")
    
        c.execute("SELECT * from director")
        rows = c.fetchall()
        print_rows1 = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows1 = print_rows1 + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows1 = print_rows1 + "\n"
        
        print(print_rows1)
        query_label = tk.Label(self, text=print_rows1)
        
        self.query_label = query_label
        self.query_label.grid(row=13, column=2,padx=0, pady=60)


        conn.commit()
        conn.close()
        

        #clear the text Boxes
        self.director_id_field.delete(0, tk.END)
        self.director_name_field.delete(0, tk.END)
        self.director_point_field.delete(0, tk.END)
       


    def delete(self):
        
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        director_d = self.director_delete_field.get()
        self.query_label.grid_forget()
        
        # insert into table
        c.execute("Delete from director where director_id = " + director_d )
        
        c.execute("SELECT * from director")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
        
        conn.commit()
        conn.close()
        
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=13, column=2,padx=0, pady=60)
        
        #clear the text Boxes
        self.director_delete_field.delete(0, tk.END)
        

class cinema_insert(tk.Frame):
    
    query_label = ""
        
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Insert Cinema", font=LARGE_FONT)
        label.grid(row=1, column=2, padx=10,pady=10)


        label = tk.Label(self, text="Delete Cinema", font=LARGE_FONT)
        label.grid(row=6, column=2, padx=10,pady=10)

        self.cinema_id_field = tk.Entry(self, width=30)
        self.cinema_id_field.grid(row=2, column=2, padx=10)
        cinema_id_field_label = tk.Label(self, text = "Enter Your Cinema ID")
        cinema_id_field_label.grid(row=2, column=1)

        self.cinema_name_field = tk.Entry(self, width=30)
        self.cinema_name_field.grid(row=3, column=2, padx=10)
        cinema_name_field_label = tk.Label(self, text = "Enter Your Cinema Name")
        cinema_name_field_label.grid(row=3, column=1)

        self.cinema_phone_field = tk.Entry(self, width=30)
        self.cinema_phone_field.grid(row=4, column=2, padx=10)
        cinema_phone_field_label = tk.Label(self, text = "Enter Your Cinema Phone Number")
        cinema_phone_field_label.grid(row=4, column=1)

        self.cinema_address_field = tk.Entry(self, width=30)
        self.cinema_address_field.grid(row=5, column=2, padx=10)
        cinema_address_field_label = tk.Label(self, text = "Enter Your Cinema Address")
        cinema_address_field_label.grid(row=5, column=1)


        self.cinema_delete_field = tk.Entry(self, width=30)
        self.cinema_delete_field.grid(row=7, column=2, padx=10)
        cinema_delete_label = tk.Label(self, text = "Enter Your Cinema ID you want to delete")
        cinema_delete_label.grid(row=7, column=1)        


        button1 = tk.Button(self,height = 1, width = 20, text="Back to Home",
                            command=lambda: controller.show_frame(StartPage))
        button1.grid(row=2, column=3,pady=0,padx=1)

        submit_btn = tk.Button(self,height = 1, width = 20 , text="add record to database",command=self.submit)
        submit_btn.grid(row=3,column=3,padx=1, pady=0)

        delete_btn = tk.Button(self,height = 1, width = 20 , text="delete",command=self.delete)
        delete_btn.grid(row=6,column=3,padx=1, pady=0)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()


        c.execute("SELECT * from cinema")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
    
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=13, column=2,padx=0, pady=60)
        

        #query_label.after(10000 , lambda: query_label.destroy())
    

        
        conn.commit()
        conn.close()
        

    def submit(self):
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        cinema_n = self.cinema_name_field.get()
        cinema_i = self.cinema_id_field.get()
        cinema_p = self.cinema_phone_field.get()
        cinema_a = self.cinema_address_field.get()
        #self.query_label.after(1 , lambda: self.query_label.pack_forget())
        #self.query_label.config(state="disabled")
        self.query_label.grid_forget()
        # insert into table
        c.execute("INSERT INTO director VALUES" + "(" + cinema_i + ",'" + cinema_a + "','" + cinema_n +  "','" + cinema_p  +   "')")
    
        c.execute("SELECT * from cinema")
        rows = c.fetchall()
        print_rows1 = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows1 = print_rows1 + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows1 = print_rows1 + "\n"
        
        print(print_rows1)
        query_label = tk.Label(self, text=print_rows1)
        
        self.query_label = query_label
        self.query_label.grid(row=13, column=2,padx=0, pady=60)


        conn.commit()
        conn.close()
        

        #clear the text Boxes
        self.director_id_field.delete(0, tk.END)
        self.director_name_field.delete(0, tk.END)
        self.director_point_field.delete(0, tk.END)
       


    def delete(self):
        
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        cinema_d = self.cinema_delete_field.get()
        self.query_label.grid_forget()
        
        # insert into table
        c.execute("Delete from cinema where cinema_id = " + cinema_d )
        
        c.execute("SELECT * from cinema")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
        
        conn.commit()
        conn.close()
        
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=13, column=2,padx=0, pady=60)
        
        #clear the text Boxes
        self.director_delete_field.delete(0, tk.END)   


class hall_insert(tk.Frame):
    
    query_label = ""
        
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Insert Hall", font=LARGE_FONT)
        label.grid(row=1, column=2, padx=10,pady=10)


        label = tk.Label(self, text="Delete Hall", font=LARGE_FONT)
        label.grid(row=9, column=2, padx=10,pady=10)

        self.hall_cinema_id_field = tk.Entry(self, width=30)
        self.hall_cinema_id_field.grid(row=2, column=2, padx=10)
        hall_cinema_id_field_label = tk.Label(self, text = "Enter The Hall Cinema ID")
        hall_cinema_id_field_label.grid(row=2, column=1)

        self.hall_id_field = tk.Entry(self, width=30)
        self.hall_id_field.grid(row=3, column=2, padx=10)
        hall_id_field_label = tk.Label(self, text = "Enter Your Hall ID")
        hall_id_field_label.grid(row=3, column=1)

        self.hall_seat_field = tk.Entry(self, width=30)
        self.hall_seat_field.grid(row=4, column=2, padx=10)
        hall_seat_field_label = tk.Label(self, text = "Enter Your Hall Seat Numbers")
        hall_seat_field_label.grid(row=4, column=1)

        self.hall_sound_field = tk.Entry(self, width=30)
        self.hall_sound_field.grid(row=5, column=2, padx=10)
        hall_sound_field_label = tk.Label(self, text = "Enter Your Hall Sound System")
        hall_sound_field_label.grid(row=5, column=1)

        self.hall_screen_field = tk.Entry(self, width=30)
        self.hall_screen_field.grid(row=6, column=2, padx=10)
        hall_screen_field_label = tk.Label(self, text = "Enter Your Hall Screen Size")
        hall_screen_field_label.grid(row=6, column=1)

        self.hall_size_field = tk.Entry(self, width=30)
        self.hall_size_field.grid(row=7, column=2, padx=10)
        hall_size_field_label = tk.Label(self, text = "Enter Your Hall Size")
        hall_size_field_label.grid(row=7, column=1)

        self.hall_name_field = tk.Entry(self, width=30)
        self.hall_name_field.grid(row=8, column=2, padx=10)
        hall_name_field_label = tk.Label(self, text = "Enter Your Hall Name")
        hall_name_field_label.grid(row=8, column=1)



        
        self.hall_cinema_delete_field = tk.Entry(self, width=30)
        self.hall_cinema_delete_field.grid(row=10, column=2, padx=10)
        hall_cinema_delete_label = tk.Label(self, text = "Enter Your Cinema ID you want to delete the Hall")
        hall_cinema_delete_label.grid(row=10, column=1)

        self.hall_delete_field = tk.Entry(self, width=30)
        self.hall_delete_field.grid(row=11, column=2, padx=10)
        hall_delete_label = tk.Label(self, text = "Enter Your Hall ID you want to delete")
        hall_delete_label.grid(row=11, column=1) 


        button1 = tk.Button(self,height = 1, width = 20, text="Back to Home",
                            command=lambda: controller.show_frame(StartPage))
        button1.grid(row=2, column=3,pady=0,padx=1)

        submit_btn = tk.Button(self,height = 1, width = 20 , text="add record to database",command=self.submit)
        submit_btn.grid(row=3,column=3,padx=1, pady=0)

        delete_btn = tk.Button(self,height = 1, width = 20 , text="delete",command=self.delete)
        delete_btn.grid(row=6,column=3,padx=1, pady=0)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()


        c.execute("SELECT * from hall")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
    
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=13, column=2,padx=0, pady=60)
        

        #query_label.after(10000 , lambda: query_label.destroy())
    

        
        conn.commit()
        conn.close()
        

    def submit(self):
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        hall_cinema_i = self.hall_cinema_id_field.get()
        hall_i = self.hall_id_field.get()
        hall_se = self.hall_seat_field.get()
        hall_so = self.hall_sound_field.get()
        hall_sc = self.hall_screen_field.get()
        hall_si = self.hall_size_field.get()
        hall_n = self.hall_name_field.get()
        #self.query_label.after(1 , lambda: self.query_label.pack_forget())
        #self.query_label.config(state="disabled")
        self.query_label.grid_forget()
        # insert into table
        c.execute("INSERT INTO hall VALUES" + "(" + hall_cinema_i + "," + hall_i + "," + hall_se + ",'" + hall_so + "'," + hall_sc + "," + hall_si + ",'" + hall_n + "')")
    
        c.execute("SELECT * from hall")
        rows = c.fetchall()
        print_rows1 = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows1 = print_rows1 + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows1 = print_rows1 + "\n"
        
        print(print_rows1)
        query_label = tk.Label(self, text=print_rows1)
        
        self.query_label = query_label
        self.query_label.grid(row=13, column=2,padx=0, pady=60)


        conn.commit()
        conn.close()
        

        #clear the text Boxes
        self.hall_id_field.delete(0, tk.END)
        self.hall_cinema_id_field.delete(0, tk.END)
        self.hall_seat_field.delete(0, tk.END)
        self.hall_sound_field.delete(0, tk.END)
        self.hall_screen_field.delete(0, tk.END)
        self.hall_size_field.delete(0, tk.END)
        self.hall_name_field.delete(0, tk.END)
       


    def delete(self):
        
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        hall_cinema_d = self.hall_cinema_delete_field.get()
        hall_d = self.hall_delete_field.get()
        self.query_label.grid_forget()
        
        # insert into table
        c.execute("Delete from cinema where hall_id = " + hall_d + " and cinema_id = " + hall_cinema_d )
        
        c.execute("SELECT * from hall")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
        
        conn.commit()
        conn.close()
        
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=13, column=2,padx=0, pady=60)
        
        #clear the text Boxes
        self.hall_cinema_delete_field.delete(0, tk.END)
        self.hall_delete_field.delete(0, tk.END)  



class session_insert(tk.Frame):
    
    query_label = ""
        
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Insert Session", font=LARGE_FONT)
        label.grid(row=1, column=2, padx=10,pady=10)


        label = tk.Label(self, text="Delete Session", font=LARGE_FONT)
        label.grid(row=7, column=2, padx=10,pady=10)

        self.session_cinema_id_field = tk.Entry(self, width=30)
        self.session_cinema_id_field.grid(row=2, column=2, padx=10)
        session_cinema_id_field_label = tk.Label(self, text = "Enter The Session Cinema ID")
        session_cinema_id_field_label.grid(row=2, column=1)

        self.session_id_field = tk.Entry(self, width=30)
        self.session_id_field.grid(row=3, column=2, padx=10)
        session_id_field_label = tk.Label(self, text = "Enter Your Session ID")
        session_id_field_label.grid(row=3, column=1)

        self.session_language_field = tk.Entry(self, width=30)
        self.session_language_field.grid(row=4, column=2, padx=10)
        session_language_field_label = tk.Label(self, text = "Enter Your Session Language")
        session_language_field_label.grid(row=4, column=1)

        self.session_start_field = tk.Entry(self, width=30)
        self.session_start_field.grid(row=5, column=2, padx=10)
        session_start_field_label = tk.Label(self, text = "Enter Your Session Start Time")
        session_start_field_label.grid(row=5, column=1)

        self.session_finish_field = tk.Entry(self, width=30)
        self.session_finish_field.grid(row=6, column=2, padx=10)
        session_finish_field_label = tk.Label(self, text = "Enter Your Session Finish Time")
        session_finish_field_label.grid(row=6, column=1)





        
        self.session_cinema_delete_field = tk.Entry(self, width=30)
        self.session_cinema_delete_field.grid(row=8, column=2, padx=10)
        session_cinema_delete_label = tk.Label(self, text = "Enter Your Session Cinema ID you want to delete")
        session_cinema_delete_label.grid(row=8, column=1)

        self.session_delete_field = tk.Entry(self, width=30)
        self.session_delete_field.grid(row=9, column=2, padx=10)
        session_delete_label = tk.Label(self, text = "Enter Your Session ID you want to delete")
        session_delete_label.grid(row=9, column=1)


        button1 = tk.Button(self,height = 1, width = 20, text="Back to Home",
                            command=lambda: controller.show_frame(StartPage))
        button1.grid(row=2, column=3,pady=0,padx=1)

        submit_btn = tk.Button(self,height = 1, width = 20 , text="add record to database",command=self.submit)
        submit_btn.grid(row=3,column=3,padx=1, pady=0)

        delete_btn = tk.Button(self,height = 1, width = 20 , text="delete",command=self.delete)
        delete_btn.grid(row=6,column=3,padx=1, pady=0)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()


        c.execute("SELECT * from sessionn")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
    
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=13, column=2,padx=0, pady=60)
        

        #query_label.after(10000 , lambda: query_label.destroy())
    

        
        conn.commit()
        conn.close()
        

    def submit(self):
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        session_cinema_i = self.session_cinema_id_field.get()
        session_i = self.session_id_field.get()
        session_l = self.session_language_field.get()
        session_s = self.session_start_field.get()
        session_f = self.session_finish_field.get()
        
        #self.query_label.after(1 , lambda: self.query_label.pack_forget())
        #self.query_label.config(state="disabled")
        self.query_label.grid_forget()
        # insert into table
        c.execute("INSERT INTO sessionn VALUES" + "(" + session_cinema_i + "," + session_i + ",'" + session_l + "','" + session_s + "','" + session_f + "')")
    
        c.execute("SELECT * from sessionn")
        rows = c.fetchall()
        print_rows1 = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows1 = print_rows1 + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows1 = print_rows1 + "\n"
        
        print(print_rows1)
        query_label = tk.Label(self, text=print_rows1)
        
        self.query_label = query_label
        self.query_label.grid(row=13, column=2,padx=0, pady=60)


        conn.commit()
        conn.close()
        

        #clear the text Boxes
        self.session_cinema_id_field.delete(0, tk.END)
        self.session_id_field.delete(0, tk.END)
        self.session_language_field.delete(0, tk.END)
        self.session_start_field.delete(0, tk.END)
        self.session_finish_field.delete(0, tk.END)



    def delete(self):
        
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        
        session_cinema_d = self.session_cinema_delete_field.get()
        session_d = self.session_delete_field.get()
        
        self.query_label.grid_forget()
        
        # insert into table
        c.execute("Delete from sessionn where cinema_id = " + session_cinema_d + "and session_id = " + session_d )
        
        c.execute("SELECT * from film")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
        
        conn.commit()
        conn.close()
        
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=13, column=2,padx=0, pady=60)
        
        #clear the text Boxes
        self.session_cinema_delete_field.delete(0, tk.END)
        self.session_delete_field.delete(0, tk.END)
          

class film_insert(tk.Frame):
    
    query_label = ""
        
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Insert Film", font=LARGE_FONT)
        label.grid(row=1, column=2, padx=10,pady=10)


        label = tk.Label(self, text="Delete Film", font=LARGE_FONT)
        label.grid(row=9, column=2, padx=10,pady=10)

        self.film_id_field = tk.Entry(self, width=30)
        self.film_id_field.grid(row=2, column=2, padx=10)
        film_id_field_label = tk.Label(self, text = "Enter The Film ID")
        film_id_field_label.grid(row=2, column=1)

        self.film_name_field = tk.Entry(self, width=30)
        self.film_name_field.grid(row=3, column=2, padx=10)
        film_name_field_label = tk.Label(self, text = "Enter Your Film Name")
        film_name_field_label.grid(row=3, column=1)

        self.film_genre_field = tk.Entry(self, width=30)
        self.film_genre_field.grid(row=4, column=2, padx=10)
        film_genre_field_label = tk.Label(self, text = "Enter Your Film Genre")
        film_genre_field_label.grid(row=4, column=1)

        self.film_age_field = tk.Entry(self, width=30)
        self.film_age_field.grid(row=5, column=2, padx=10)
        film_age_field_label = tk.Label(self, text = "Enter Your Film Min Age")
        film_age_field_label.grid(row=5, column=1)

        self.film_date_field = tk.Entry(self, width=30)
        self.film_date_field.grid(row=6, column=2, padx=10)
        film_date_field_label = tk.Label(self, text = "Enter Your Film Biuld Date")
        film_date_field_label.grid(row=6, column=1)

        self.film_director_field = tk.Entry(self, width=30)
        self.film_director_field.grid(row=7, column=2, padx=10)
        film_director_field_label = tk.Label(self, text = "Enter Your Film Director ID")
        film_director_field_label.grid(row=7, column=1)

        self.film_codirector_field = tk.Entry(self, width=30)
        self.film_codirector_field.grid(row=8, column=2, padx=10)
        film_codirector_field_label = tk.Label(self, text = "Enter Your Film Co-Director Name")
        film_codirector_field_label.grid(row=8, column=1)



        
        self.film_delete_field = tk.Entry(self, width=30)
        self.film_delete_field.grid(row=10, column=2, padx=10)
        film_delete_label = tk.Label(self, text = "Enter Your Film ID you want to delete the Hall")
        film_delete_label.grid(row=10, column=1)


        button1 = tk.Button(self,height = 1, width = 20, text="Back to Home",
                            command=lambda: controller.show_frame(StartPage))
        button1.grid(row=2, column=3,pady=0,padx=1)

        submit_btn = tk.Button(self,height = 1, width = 20 , text="add record to database",command=self.submit)
        submit_btn.grid(row=3,column=3,padx=1, pady=0)

        delete_btn = tk.Button(self,height = 1, width = 20 , text="delete",command=self.delete)
        delete_btn.grid(row=6,column=3,padx=1, pady=0)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()


        c.execute("SELECT * from film")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
    
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=13, column=2,padx=0, pady=60)
        

        #query_label.after(10000 , lambda: query_label.destroy())
    

        
        conn.commit()
        conn.close()
        

    def submit(self):
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        film_i = self.film_id_field.get()
        film_n = self.film_name_field.get()
        film_g = self.film_genre_field.get()
        film_a = self.film_age_field.get()
        film_da = self.film_date_field.get()
        film_di = self.film_director_field.get()
        film_c = self.film_codirector_field.get()
        #self.query_label.after(1 , lambda: self.query_label.pack_forget())
        #self.query_label.config(state="disabled")
        self.query_label.grid_forget()
        # insert into table
        c.execute("INSERT INTO film VALUES" + "(" + film_i + ",'" + film_n + "','" + film_g + "'," + film_a + ",'" + film_da + "'," + film_di + ",'" + film_c + "')")
    
        c.execute("SELECT * from film")
        rows = c.fetchall()
        print_rows1 = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows1 = print_rows1 + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows1 = print_rows1 + "\n"
        
        print(print_rows1)
        query_label = tk.Label(self, text=print_rows1)
        
        self.query_label = query_label
        self.query_label.grid(row=13, column=2,padx=0, pady=60)


        conn.commit()
        conn.close()
        

        #clear the text Boxes
        self.film_id_field.delete(0, tk.END)
        self.film_name_id_field.delete(0, tk.END)
        self.film_genre_field.delete(0, tk.END)
        self.film_age_field.delete(0, tk.END)
        self.film_date_field.delete(0, tk.END)
        self.film_director_field.delete(0, tk.END)
        self.film_codirector_field.delete(0, tk.END)
       


    def delete(self):
        
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        film_d = self.film_delete_field.get()
        
        self.query_label.grid_forget()
        
        # insert into table
        c.execute("Delete from film where film_id = " + film_d  )
        
        c.execute("SELECT * from film")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
        
        conn.commit()
        conn.close()
        
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=13, column=2,padx=0, pady=60)
        
        #clear the text Boxes
        self.film_delete_field.delete(0, tk.END)
          



class user_insert(tk.Frame):
    
    query_label = ""
        
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Insert User", font=LARGE_FONT)
        label.grid(row=1, column=2, padx=10,pady=10)


        label = tk.Label(self, text="Delete User", font=LARGE_FONT)
        label.grid(row=7, column=2, padx=10,pady=10)

        self.user_id_field = tk.Entry(self, width=30)
        self.user_id_field.grid(row=2, column=2, padx=10)
        user_id_field_label = tk.Label(self, text = "Enter The User ID")
        user_id_field_label.grid(row=2, column=1)

        self.user_email_field = tk.Entry(self, width=30)
        self.user_email_field.grid(row=3, column=2, padx=10)
        user_email_field_label = tk.Label(self, text = "Enter Your User Email")
        user_email_field_label.grid(row=3, column=1)

        self.user_phone_field = tk.Entry(self, width=30)
        self.user_phone_field.grid(row=4, column=2, padx=10)
        user_phone_field_label = tk.Label(self, text = "Enter Your User Phone Number")
        user_phone_field_label.grid(row=4, column=1)

        self.user_name_field = tk.Entry(self, width=30)
        self.user_name_field.grid(row=5, column=2, padx=10)
        user_name_field_label = tk.Label(self, text = "Enter Your User Name")
        user_name_field_label.grid(row=5, column=1)

        self.user_password_field = tk.Entry(self, width=30)
        self.user_password_field.grid(row=6, column=2, padx=10)
        user_password_field_label = tk.Label(self, text = "Enter Your Password")
        user_password_field_label.grid(row=6, column=1)





        
        self.user_delete_field = tk.Entry(self, width=30)
        self.user_delete_field.grid(row=8, column=2, padx=10)
        user_delete_label = tk.Label(self, text = "Enter Your User ID you want to delete")
        user_delete_label.grid(row=8, column=1)


        button1 = tk.Button(self,height = 1, width = 20, text="Back to Home",
                            command=lambda: controller.show_frame(StartPage))
        button1.grid(row=2, column=3,pady=0,padx=1)

        submit_btn = tk.Button(self,height = 1, width = 20 , text="add record to database",command=self.submit)
        submit_btn.grid(row=3,column=3,padx=1, pady=0)

        delete_btn = tk.Button(self,height = 1, width = 20 , text="delete",command=self.delete)
        delete_btn.grid(row=6,column=3,padx=1, pady=0)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()


        c.execute("SELECT * from userr join registered on registered_id = user_id")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
    
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=13, column=2,padx=0, pady=60)
        

        #query_label.after(10000 , lambda: query_label.destroy())
    

        
        conn.commit()
        conn.close()
        

    def submit(self):
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        
        user_i = self.user_id_field.get()
        user_e = self.user_email_field.get()
        user_ph = self.user_phone_field.get()
        user_n = self.user_name_field.get()
        user_pa = self.user_password_field.get()
        
        #self.query_label.after(1 , lambda: self.query_label.pack_forget())
        #self.query_label.config(state="disabled")
        self.query_label.grid_forget()
        # insert into table
        c.execute("INSERT INTO registered VALUES" + "(" + user_i + ",'" + user_e + "','" + user_ph + "','" + user_n + "','" + user_pa + "')")
        c.execute("INSERT INTO userr VALUES" + "(" + user_i + ")")
    
        c.execute("SELECT * from userr join registered on registered_id = user_id")
        rows = c.fetchall()
        print_rows1 = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows1 = print_rows1 + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows1 = print_rows1 + "\n"
        
        print(print_rows1)
        query_label = tk.Label(self, text=print_rows1)
        
        self.query_label = query_label
        self.query_label.grid(row=13, column=2,padx=0, pady=60)


        conn.commit()
        conn.close()
        

        #clear the text Boxes
        self.user_id_field.delete(0, tk.END)
        self.user_email_field.delete(0, tk.END)
        self.user_phone_field.delete(0, tk.END)
        self.user_name_field.delete(0, tk.END)
        self.user_password_field.delete(0, tk.END)
  
       


    def delete(self):
        
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        user_d = self.user_delete_field.get()
        
        self.query_label.grid_forget()
        
        # insert into table
        c.execute("Delete from userr where user_id = " + user_d  )
        
        c.execute("SELECT * from userr join registered on registered_id = user_id")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
        
        conn.commit()
        conn.close()
        
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=13, column=2,padx=0, pady=60)
        
        #clear the text Boxes
        self.user_delete_field.delete(0, tk.END)





class admin_insert(tk.Frame):
    
    query_label = ""
        
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Insert Admin", font=LARGE_FONT)
        label.grid(row=1, column=2, padx=10,pady=10)


        label = tk.Label(self, text="Delete Admin", font=LARGE_FONT)
        label.grid(row=8, column=2, padx=10,pady=10)

        self.admin_id_field = tk.Entry(self, width=30)
        self.admin_id_field.grid(row=2, column=2, padx=10)
        admin_id_field_label = tk.Label(self, text = "Enter The Admin ID")
        admin_id_field_label.grid(row=2, column=1)

        self.admin_email_field = tk.Entry(self, width=30)
        self.admin_email_field.grid(row=3, column=2, padx=10)
        admin_email_field_label = tk.Label(self, text = "Enter Your Admin Email")
        admin_email_field_label.grid(row=3, column=1)

        self.admin_phone_field = tk.Entry(self, width=30)
        self.admin_phone_field.grid(row=4, column=2, padx=10)
        admin_phone_field_label = tk.Label(self, text = "Enter Your Admin Phone Number")
        admin_phone_field_label.grid(row=4, column=1)

        self.admin_name_field = tk.Entry(self, width=30)
        self.admin_name_field.grid(row=5, column=2, padx=10)
        admin_name_field_label = tk.Label(self, text = "Enter Your Admin Name")
        admin_name_field_label.grid(row=5, column=1)

        self.admin_password_field = tk.Entry(self, width=30)
        self.admin_password_field.grid(row=6, column=2, padx=10)
        admin_password_field_label = tk.Label(self, text = "Enter Your Password")
        admin_password_field_label.grid(row=6, column=1)


        self.admin_cinema_id_field = tk.Entry(self, width=30)
        self.admin_cinema_id_field.grid(row=7, column=2, padx=10)
        admin_cinema_id_field_label = tk.Label(self, text = "Enter Your Admin Cinema ID")
        admin_cinema_id_field_label.grid(row=7, column=1)





        
        self.admin_delete_field = tk.Entry(self, width=30)
        self.admin_delete_field.grid(row=9, column=2, padx=10)
        admin_delete_label = tk.Label(self, text = "Enter Your Admin ID you want to delete")
        admin_delete_label.grid(row=9, column=1)


        button1 = tk.Button(self,height = 1, width = 20, text="Back to Home",
                            command=lambda: controller.show_frame(StartPage))
        button1.grid(row=2, column=3,pady=0,padx=1)

        submit_btn = tk.Button(self,height = 1, width = 20 , text="add record to database",command=self.submit)
        submit_btn.grid(row=3,column=3,padx=1, pady=0)

        delete_btn = tk.Button(self,height = 1, width = 20 , text="delete",command=self.delete)
        delete_btn.grid(row=6,column=3,padx=1, pady=0)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()


        c.execute("SELECT * from adminn join registered on registered_id = admin_id")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
    
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=13, column=2,padx=0, pady=60)
        

        #query_label.after(10000 , lambda: query_label.destroy())
    

        
        conn.commit()
        conn.close()
        

    def submit(self):
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        
        admin_i = self.admin_id_field.get()
        admin_e = self.admin_email_field.get()
        admin_ph = self.admin_phone_field.get()
        admin_n = self.admin_name_field.get()
        admin_pa = self.admin_password_field.get()
        admin_cinema_id = self.admin_cinema_id_field.get()
        
        #self.query_label.after(1 , lambda: self.query_label.pack_forget())
        #self.query_label.config(state="disabled")
        self.query_label.grid_forget()
        # insert into table
        c.execute("INSERT INTO registered VALUES" + "(" + admin_i + ",'" + admin_e + "','" + admin_ph + "','" + admin_n + "','" + admin_pa + "')")
        c.execute("INSERT INTO adminn VALUES" + "(" + admin_i + "," + admin_cinema_id + ")")
    
        c.execute("SELECT * from adminn join registered on registered_id = admin_id")
        rows = c.fetchall()
        print_rows1 = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows1 = print_rows1 + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows1 = print_rows1 + "\n"
        
        print(print_rows1)
        query_label = tk.Label(self, text=print_rows1)
        
        self.query_label = query_label
        self.query_label.grid(row=13, column=2,padx=0, pady=60)


        conn.commit()
        conn.close()
        

        #clear the text Boxes
        self.admin_id_field.delete(0, tk.END)
        self.admin_email_field.delete(0, tk.END)
        self.admin_phone_field.delete(0, tk.END)
        self.admin_name_field.delete(0, tk.END)
        self.admin_password_field.delete(0, tk.END)
        self.admin_cinema_id_field.delete(0, tk.END)
  
       


    def delete(self):
        
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        admin_d = self.admin_delete_field.get()
        
        self.query_label.grid_forget()
        
        # insert into table
        c.execute("Delete from adminn where admin_id = " + admin_d  )
        
        c.execute("SELECT * from userr join registered on registered_id = admin_id")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
        
        conn.commit()
        conn.close()
        
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=13, column=2,padx=0, pady=60)
        
        #clear the text Boxes
        self.admin_delete_field.delete(0, tk.END)


class unreserved_ticket_insert(tk.Frame):
    
    query_label = ""
        
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Insert Unreserved Ticket", font=LARGE_FONT)
        label.grid(row=1, column=2, padx=10,pady=10)


        label = tk.Label(self, text="Delete Unreserved Ticket", font=LARGE_FONT)
        label.grid(row=10, column=2, padx=10,pady=10)

        self.ticket_id_field = tk.Entry(self, width=30)
        self.ticket_id_field.grid(row=2, column=2, padx=10)
        ticket_id_field_label = tk.Label(self, text = "Enter The Ticket ID")
        ticket_id_field_label.grid(row=2, column=1)

        self.hall_id_field = tk.Entry(self, width=30)
        self.hall_id_field.grid(row=3, column=2, padx=10)
        hall_id_field_label = tk.Label(self, text = "Enter Your Ticket Hall ID")
        hall_id_field_label.grid(row=3, column=1)

        self.cinema_id_field = tk.Entry(self, width=30)
        self.cinema_id_field.grid(row=4, column=2, padx=10)
        cinema_id_field_label = tk.Label(self, text = "Enter Your Ticket Cinema ID")
        cinema_id_field_label.grid(row=4, column=1)

        self.session_id_field = tk.Entry(self, width=30)
        self.session_id_field.grid(row=5, column=2, padx=10)
        session_id_field_label = tk.Label(self, text = "Enter Your Ticket Session ID")
        session_id_field_label.grid(row=5, column=1)

        self.film_id_field = tk.Entry(self, width=30)
        self.film_id_field.grid(row=6, column=2, padx=10)
        film_id_field_label = tk.Label(self, text = "Enter Your Ticket Film ID")
        film_id_field_label.grid(row=6, column=1)


        self.ticket_price_field = tk.Entry(self, width=30)
        self.ticket_price_field.grid(row=7, column=2, padx=10)
        ticket_price_field_label = tk.Label(self, text = "Enter Your Ticket Price")
        ticket_price_field_label.grid(row=7, column=1)

        self.ticket_seat_field = tk.Entry(self, width=30)
        self.ticket_seat_field.grid(row=8, column=2, padx=10)
        ticket_seat_field_label = tk.Label(self, text = "Enter Your Ticket Seat Number")
        ticket_seat_field_label.grid(row=8, column=1)


        self.ticket_admin_field = tk.Entry(self, width=30)
        self.ticket_admin_field.grid(row=9, column=2, padx=10)
        ticket_admin_field_label = tk.Label(self, text = "Enter Your Ticket Admin ID")
        ticket_admin_field_label.grid(row=9, column=1)

    
        
        self.admin1_delete_field = tk.Entry(self, width=30)
        self.admin1_delete_field.grid(row=11, column=2, padx=10)
        admin1_delete_label = tk.Label(self, text = "Enter Your Ticket ID you want to delete")
        admin1_delete_label.grid(row=11, column=1)

        self.admin2_delete_field = tk.Entry(self, width=30)
        self.admin2_delete_field.grid(row=12, column=2, padx=10)
        admin2_delete_label = tk.Label(self, text = "Enter Your Ticket Hall ID you want to delete")
        admin2_delete_label.grid(row=12, column=1)

        self.admin3_delete_field = tk.Entry(self, width=30)
        self.admin3_delete_field.grid(row=13, column=2, padx=10)
        admin3_delete_label = tk.Label(self, text = "Enter Your Ticket Cinema ID you want to delete")
        admin3_delete_label.grid(row=13, column=1)

        self.admin4_delete_field = tk.Entry(self, width=30)
        self.admin4_delete_field.grid(row=14, column=2, padx=10)
        admin4_delete_label = tk.Label(self, text = "Enter Your Ticket Session ID you want to delete")
        admin4_delete_label.grid(row=14, column=1)

        self.admin5_delete_field = tk.Entry(self, width=30)
        self.admin5_delete_field.grid(row=15, column=2, padx=10)
        admin5_delete_label = tk.Label(self, text = "Enter Your Ticket Film ID you want to delete")
        admin5_delete_label.grid(row=15, column=1)


        button1 = tk.Button(self,height = 1, width = 20, text="Back to Home",
                            command=lambda: controller.show_frame(StartPage))
        button1.grid(row=2, column=3,pady=0,padx=1)

        submit_btn = tk.Button(self,height = 1, width = 20 , text="add record to database",command=self.submit)
        submit_btn.grid(row=3,column=3,padx=1, pady=0)

        delete_btn = tk.Button(self,height = 1, width = 20 , text="delete",command=self.delete)
        delete_btn.grid(row=6,column=3,padx=1, pady=0)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()


        c.execute("SELECT * from ticket join unreserved_ticket on (unreserved_ticket_id = ticket_id and uhall_id = hall_id and ucinema_id = cinema_id and usession_id = session_id and ufilm_id = film_id)")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
    
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=16, column=2,padx=0, pady=60)
        

        #query_label.after(10000 , lambda: query_label.destroy())
    

        
        conn.commit()
        conn.close()
        

    def submit(self):
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        
        ticket_i = self.ticket_id_field.get()
        ticket_h = self.hall_id_field.get()
        ticket_c = self.cinema_id_field.get()
        ticket_ses = self.session_id_field.get()
        ticket_f = self.film_id_field.get()
        ticket_p =self.ticket_price_field.get()
        ticket_sea =self.ticket_seat_field.get()
        ticket_a =self.ticket_admin_field.get()
       
        
        #self.query_label.after(1 , lambda: self.query_label.pack_forget())
        #self.query_label.config(state="disabled")
        self.query_label.grid_forget()
        # insert into table
        c.execute("INSERT INTO ticket VALUES" + "(" + ticket_i + "," + ticket_h + "," + ticket_c + "," + ticket_ses + "," + ticket_f + "," + ticket_p + "," + ticket_sea + "," + ticket_a + ")")
        c.execute("INSERT INTO unreserved_ticket VALUES" + "(" + ticket_i + "," + ticket_h + "," + ticket_c + "," + ticket_ses + "," + ticket_f + ")")
    
        c.execute("SELECT * from ticket join unreserved_ticket on (unreserved_ticket_id = ticket_id and uhall_id = hall_id and ucinema_id = cinema_id and usession_id = session_id and ufilm_id = film_id)")
        rows = c.fetchall()
        print_rows1 = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows1 = print_rows1 + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows1 = print_rows1 + "\n"
        
        print(print_rows1)
        query_label = tk.Label(self, text=print_rows1)
        
        self.query_label = query_label
        self.query_label.grid(row=16, column=2,padx=0, pady=60)


        conn.commit()
        conn.close()
        

        #clear the text Boxes
        self.ticket_id_field.delete(0, tk.END)
        self.hall_id_field.delete(0, tk.END)
        self.cinema_id_field.delete(0, tk.END)
        self.session_id_field.delete(0, tk.END)
        self.film_id_field.delete(0, tk.END)
        self.ticket_price_field.delete(0, tk.END)
        self.ticket_seat_field.delete(0, tk.END)
        self.ticket_admin_field.delete(0, tk.END)
  
       


    def delete(self):
        
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        
        admin1_d =  self.admin1_delete_field.get()
        admin2_d = self.admin2_delete_field.get()
        admin3_d = self.admin3_delete_field.get()
        admin4_d = self.admin4_delete_field.get()
        admin5_d = self.admin5_delete_field.get()
        
        self.query_label.grid_forget()
        
        # insert into table
        c.execute("Delete from unreserved_ticket where unreserved_ticket_id = " + admin1_d + "and uhall_id =" + admin2_d + "and ucinema_id =" + admin3_d + "and usession_id = " + admin4_d + "and ufilm_id = " + admin5_d )
        
        c.execute("SELECT * from ticket join unreserved_ticket on (unreserved_ticket_id = ticket_id and uhall_id = hall_id and ucinema_id = cinema_id and usession_id = session_id and ufilm_id = film_id)")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
        
        conn.commit()
        conn.close()
        
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=16, column=2,padx=0, pady=60)
        
        #clear the text Boxes
        self.admin1_delete_field.delete(0, tk.END)
        self.admin2_delete_field.delete(0, tk.END)
        self.admin3_delete_field.delete(0, tk.END)
        self.admin4_delete_field.delete(0, tk.END)
        self.admin5_delete_field.delete(0, tk.END)


        
class reserved_ticket_insert(tk.Frame):
    
    query_label = ""
        
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Insert Reserved Ticket", font=LARGE_FONT)
        label.grid(row=1, column=2, padx=10,pady=10)


        label = tk.Label(self, text="Delete Reserved Ticket", font=LARGE_FONT)
        label.grid(row=10, column=2, padx=10,pady=10)

        self.ticket_id_field = tk.Entry(self, width=30)
        self.ticket_id_field.grid(row=2, column=2, padx=10)
        ticket_id_field_label = tk.Label(self, text = "Enter The Ticket ID")
        ticket_id_field_label.grid(row=2, column=1)

        self.hall_id_field = tk.Entry(self, width=30)
        self.hall_id_field.grid(row=3, column=2, padx=10)
        hall_id_field_label = tk.Label(self, text = "Enter Your Ticket Hall ID")
        hall_id_field_label.grid(row=3, column=1)

        self.cinema_id_field = tk.Entry(self, width=30)
        self.cinema_id_field.grid(row=4, column=2, padx=10)
        cinema_id_field_label = tk.Label(self, text = "Enter Your Ticket Cinema ID")
        cinema_id_field_label.grid(row=4, column=1)

        self.session_id_field = tk.Entry(self, width=30)
        self.session_id_field.grid(row=5, column=2, padx=10)
        session_id_field_label = tk.Label(self, text = "Enter Your Ticket Session ID")
        session_id_field_label.grid(row=5, column=1)

        self.film_id_field = tk.Entry(self, width=30)
        self.film_id_field.grid(row=6, column=2, padx=10)
        film_id_field_label = tk.Label(self, text = "Enter Your Ticket Film ID")
        film_id_field_label.grid(row=6, column=1)


        self.ticket_price_field = tk.Entry(self, width=30)
        self.ticket_price_field.grid(row=7, column=2, padx=10)
        ticket_price_field_label = tk.Label(self, text = "Enter Your Ticket Price")
        ticket_price_field_label.grid(row=7, column=1)

        self.ticket_seat_field = tk.Entry(self, width=30)
        self.ticket_seat_field.grid(row=8, column=2, padx=10)
        ticket_seat_field_label = tk.Label(self, text = "Enter Your Ticket Seat Number")
        ticket_seat_field_label.grid(row=8, column=1)


        self.ticket_admin_field = tk.Entry(self, width=30)
        self.ticket_admin_field.grid(row=9, column=2, padx=10)
        ticket_admin_field_label = tk.Label(self, text = "Enter Your Ticket Admin ID")
        ticket_admin_field_label.grid(row=9, column=1)

    
        
        self.admin1_delete_field = tk.Entry(self, width=30)
        self.admin1_delete_field.grid(row=11, column=2, padx=10)
        admin1_delete_label = tk.Label(self, text = "Enter Your Ticket ID you want to delete")
        admin1_delete_label.grid(row=11, column=1)

        self.admin2_delete_field = tk.Entry(self, width=30)
        self.admin2_delete_field.grid(row=12, column=2, padx=10)
        admin2_delete_label = tk.Label(self, text = "Enter Your Ticket Hall ID you want to delete")
        admin2_delete_label.grid(row=12, column=1)

        self.admin3_delete_field = tk.Entry(self, width=30)
        self.admin3_delete_field.grid(row=13, column=2, padx=10)
        admin3_delete_label = tk.Label(self, text = "Enter Your Ticket Cinema ID you want to delete")
        admin3_delete_label.grid(row=13, column=1)

        self.admin4_delete_field = tk.Entry(self, width=30)
        self.admin4_delete_field.grid(row=14, column=2, padx=10)
        admin4_delete_label = tk.Label(self, text = "Enter Your Ticket Session ID you want to delete")
        admin4_delete_label.grid(row=14, column=1)

        self.admin5_delete_field = tk.Entry(self, width=30)
        self.admin5_delete_field.grid(row=15, column=2, padx=10)
        admin5_delete_label = tk.Label(self, text = "Enter Your Ticket Film ID you want to delete")
        admin5_delete_label.grid(row=15, column=1)


        button1 = tk.Button(self,height = 1, width = 20, text="Back to Home",
                            command=lambda: controller.show_frame(StartPage))
        button1.grid(row=2, column=3,pady=0,padx=1)

        submit_btn = tk.Button(self,height = 1, width = 20 , text="add record to database",command=self.submit)
        submit_btn.grid(row=3,column=3,padx=1, pady=0)

        delete_btn = tk.Button(self,height = 1, width = 20 , text="delete",command=self.delete)
        delete_btn.grid(row=6,column=3,padx=1, pady=0)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()


        c.execute("SELECT * from ticket join unreserved_ticket on (unreserved_ticket_id = ticket_id and uhall_id = hall_id and ucinema_id = cinema_id and usession_id = session_id and ufilm_id = film_id)")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
    
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=16, column=2,padx=0, pady=60)
        

        #query_label.after(10000 , lambda: query_label.destroy())
    

        
        conn.commit()
        conn.close()
        

    def submit(self):
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        
        ticket_i = self.ticket_id_field.get()
        ticket_h = self.hall_id_field.get()
        ticket_c = self.cinema_id_field.get()
        ticket_ses = self.session_id_field.get()
        ticket_f = self.film_id_field.get()
        ticket_p =self.ticket_price_field.get()
        ticket_sea =self.ticket_seat_field.get()
        ticket_a =self.ticket_admin_field.get()
       
        
        #self.query_label.after(1 , lambda: self.query_label.pack_forget())
        #self.query_label.config(state="disabled")
        self.query_label.grid_forget()
        # insert into table
        c.execute("INSERT INTO ticket VALUES" + "(" + ticket_i + "," + ticket_h + "," + ticket_c + "," + ticket_ses + "," + ticket_f + "," + ticket_p + "," + ticket_sea + "," + ticket_a + ")")
        c.execute("INSERT INTO unreserved_ticket VALUES" + "(" + ticket_i + "," + ticket_h + "," + ticket_c + "," + ticket_ses + "," + ticket_f + ")")
    
        c.execute("SELECT * from ticket join unreserved_ticket on (unreserved_ticket_id = ticket_id and uhall_id = hall_id and ucinema_id = cinema_id and usession_id = session_id and ufilm_id = film_id)")
        rows = c.fetchall()
        print_rows1 = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows1 = print_rows1 + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows1 = print_rows1 + "\n"
        
        print(print_rows1)
        query_label = tk.Label(self, text=print_rows1)
        
        self.query_label = query_label
        self.query_label.grid(row=16, column=2,padx=0, pady=60)


        conn.commit()
        conn.close()
        

        #clear the text Boxes
        self.ticket_id_field.delete(0, tk.END)
        self.hall_id_field.delete(0, tk.END)
        self.cinema_id_field.delete(0, tk.END)
        self.session_id_field.delete(0, tk.END)
        self.film_id_field.delete(0, tk.END)
        self.ticket_price_field.delete(0, tk.END)
        self.ticket_seat_field.delete(0, tk.END)
        self.ticket_admin_field.delete(0, tk.END)
  
       


    def delete(self):
        
        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")
        c = conn.cursor()
        
        admin1_d =  self.admin1_delete_field.get()
        admin2_d = self.admin2_delete_field.get()
        admin3_d = self.admin3_delete_field.get()
        admin4_d = self.admin4_delete_field.get()
        admin5_d = self.admin5_delete_field.get()
        
        self.query_label.grid_forget()
        
        # insert into table
        c.execute("Delete from unreserved_ticket where unreserved_ticket_id = " + admin1_d + "and uhall_id =" + admin2_d + "and ucinema_id =" + admin3_d + "and usession_id = " + admin4_d + "and ufilm_id = " + admin5_d )
        
        c.execute("SELECT * from ticket join unreserved_ticket on (unreserved_ticket_id = ticket_id and uhall_id = hall_id and ucinema_id = cinema_id and usession_id = session_id and ufilm_id = film_id)")
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])        
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1  
            print_rows = print_rows + "\n"
        
        
        conn.commit()
        conn.close()
        
        self.query_label = tk.Label(self, text=print_rows)
        self.query_label.grid(row=16, column=2,padx=0, pady=60)
        
        #clear the text Boxes
        self.admin1_delete_field.delete(0, tk.END)
        self.admin2_delete_field.delete(0, tk.END)
        self.admin3_delete_field.delete(0, tk.END)
        self.admin4_delete_field.delete(0, tk.END)
        self.admin5_delete_field.delete(0, tk.END)





        
class query(tk.Frame):
    
    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="Queries Page", font=LARGE_FONT)
        label.pack(pady=10,padx=10)

        qq1 = tk.Button(self, width = 45, text="show cinema list order by hall numbers",
                            command=lambda: controller.show_frame(q1))
        qq1.pack()

        qq2 = tk.Button(self, width = 45, text="show actor name order by points in a movie",
                            command=lambda: controller.show_frame(q2))
        qq2.pack()

        qq3 = tk.Button(self, width = 45, text="show hall id order by capaity in a cinema",
                            command=lambda: controller.show_frame(q3))
        qq3.pack()

        qq4 = tk.Button(self, width = 45, text="show average points of actors",
                            command=lambda: controller.show_frame(q4))
        qq4.pack()

        qq5 = tk.Button(self, width = 45, text="show a directors working history with actors",
                            command=lambda: controller.show_frame(q5))
        qq5.pack()

        qq6 = tk.Button(self, width = 45, text="show movie list order by biuld date",
                            command=lambda: controller.show_frame(q6))
        qq6.pack()

        qq7 = tk.Button(self, width = 45, text="number of ticket reserved of a session in a cinema",
                            command=lambda: controller.show_frame(q7))
        qq7.pack()

        qq8 = tk.Button(self, width = 45, text="show user names order by tikcet buying",
                            command=lambda: controller.show_frame(q8))
        qq8.pack()

        qq9 = tk.Button(self, width = 45, text="director list with their movies",
                            command=lambda: controller.show_frame(q9))
        qq9.pack()

        qq10 = tk.Button(self, width = 45, text="most tikcet sold by admins",
                            command=lambda: controller.show_frame(q10))
        qq10.pack()


        qq11 = tk.Button(self, width = 45, text="show ticket numbers of a session",
                            command=lambda: controller.show_frame(q11))
        qq11.pack()


        qq12 = tk.Button(self, width = 45, text="most sold movie of all time",
                            command=lambda: controller.show_frame(q12))
        qq12.pack()


        qq13 = tk.Button(self, width = 45, text="most working actors",
                            command=lambda: controller.show_frame(q13))
        qq13.pack()


        qq14 = tk.Button(self, width = 45, text="list of all sessions of a cinema",
                            command=lambda: controller.show_frame(q14))
        qq14.pack()

        qq15 = tk.Button(self, width = 45, text="directors ranking",
                            command=lambda: controller.show_frame(q15))
        qq15.pack()

        qq17 = tk.Button(self, width = 45, text="show actor edit history",
                            command=lambda: controller.show_frame(q17))
        qq17.pack()


        qq18 = tk.Button(self, width = 45, text="show director edit history",
                            command=lambda: controller.show_frame(q18))
        qq18.pack()

        
        button1 = tk.Button(self,height = 1, width = 20, text="Back to Home",
                            command=lambda: controller.show_frame(StartPage))
        button1.pack()


class q1(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="cinema list order by hall numbers", font=LARGE_FONT)
        label.grid(row=1, column=5,pady=10,padx=500)
        
        button1 = tk.Button(self,height = 1, width = 20, text="Back to Query Page",
                            command=lambda: controller.show_frame(query))
        button1.grid(row=3, column=5,pady=0,padx=1)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()

    
        c.execute("select cinema_id,cinema_name,count(cinema_id) from cinema natural join hall group by (cinema_id,cinema_name) order by (cinema_id,cinema_name) " )
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])
    
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1
            
            print_rows = print_rows + "\n"
        
    
        query_label = tk.Label(self, text=print_rows)
        query_label.grid(row=2, column=5,columnspan=2)


        conn.commit()
        conn.close()



class q2(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="actor name order by points in a movie", font=LARGE_FONT)
        label.grid(row=1, column=1,pady=0,padx=1)

        button1 = tk.Button(self,height = 1, width = 20, text="Back to Query Page",
                            command=lambda: controller.show_frame(query))
        button1.grid(row=4, column=2,pady=0,padx=1)

        Q2_btn = tk.Button(self,height = 1, width = 35 , text="show actor name order by points in a movie",command=self.Q2)
        Q2_btn.grid(row=3,column=2,columnspan=2,pady=20,padx=10,ipadx=13)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()

        self.movie_field = tk.Entry(self, width=30)
        self.movie_field.grid(row=3, column=1, padx=20)
        self.movie_field_label = tk.Label(self, text = "Enter Your Movie Name")
        self.movie_field_label.grid(row=3, column=0)

        conn.commit()
        conn.close() 

    def Q2(self):

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()
        
        movieF = self.movie_field.get()
        c.execute("select actor_name,actor_point_100 from get_actor_movie('" + movieF + "'); " )
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])
    
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1
            
            print_rows = print_rows + "\n"
        
    
        query_label = tk.Label(self, text=print_rows)
        query_label.grid(row=5, column=0,columnspan=2)

        query_label.after(10000 , lambda: query_label.destroy())
    
        

        conn.commit()
        conn.close()    


    
class q3(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="hall id order by capaity in a cinema", font=LARGE_FONT)
        label.grid(row=1, column=1,pady=0,padx=1)

        button1 = tk.Button(self,height = 1, width = 20, text="Back to Query Page",
                            command=lambda: controller.show_frame(query))
        button1.grid(row=4, column=2,pady=0,padx=1)

        Q2_btn = tk.Button(self,height = 1, width = 35 , text="show hall id order by capaity in a cinema",command=self.Q2)
        Q2_btn.grid(row=3,column=2,columnspan=2,pady=20,padx=10,ipadx=13)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()

        self.movie_field = tk.Entry(self, width=30)
        self.movie_field.grid(row=3, column=1, padx=20)
        self.movie_field_label = tk.Label(self, text = "Enter Your Cinema Name")
        self.movie_field_label.grid(row=3, column=0)

        conn.commit()
        conn.close() 

    def Q2(self):

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()
        
        movieF = self.movie_field.get()
        
        c.execute("select cinema_name,hall_id,seat_number from get_cinema_hall('" + movieF + "'); " )
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])
    
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1
            
            print_rows = print_rows + "\n"
        
    
        query_label = tk.Label(self, text=print_rows)
        query_label.grid(row=6, column=0,columnspan=2)

        query_label.after(10000 , lambda: query_label.destroy())
    
        

        conn.commit()
        conn.close()    
    
        


class q4(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="average points of actors", font=LARGE_FONT)
        label.grid(row=1, column=1,pady=0,padx=500)
        
        button1 = tk.Button(self,height = 1, width = 20, text="Back to Query Page",
                            command=lambda: controller.show_frame(query))
        button1.grid(row=3, column=1,pady=0,padx=1)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()

    
        c.execute("select actor_name,avg(actor_point_100) from actor natural join film_actor group by actor_name order by avg(actor_point_100) desc" )
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])
    
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1
            
            print_rows = print_rows + "\n"
        
    
        query_label = tk.Label(self, text=print_rows)
        query_label.grid(row=2, column=1,columnspan=2)


        conn.commit()
        conn.close()

        

class q5(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="a directors working history with actors", font=LARGE_FONT)
        label.grid(row=1, column=1,pady=0,padx=1)

        button1 = tk.Button(self,height = 1, width = 20, text="Back to Query Page",
                            command=lambda: controller.show_frame(query))
        button1.grid(row=4, column=2,pady=0,padx=1)

        Q2_btn = tk.Button(self,height = 1, width = 35 , text="show a directors working history with actors",command=self.Q2)
        Q2_btn.grid(row=3,column=2,columnspan=2,pady=20,padx=10,ipadx=13)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()

        self.movie_field = tk.Entry(self, width=30)
        self.movie_field.grid(row=3, column=1, padx=20)
        self.movie_field_label = tk.Label(self, text = "Enter Your Director Name")
        self.movie_field_label.grid(row=3, column=0)

        conn.commit()
        conn.close() 

    def Q2(self):

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()
        
        movieF = self.movie_field.get()
        
        c.execute("select director_name,actor_name from get_actor_director('" + movieF + "') group by (director_name,actor_name); " )
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])
    
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1
            
            print_rows = print_rows + "\n"
        
    
        query_label = tk.Label(self, text=print_rows)
        query_label.grid(row=6, column=0,columnspan=2)

        query_label.after(10000 , lambda: query_label.destroy())
    
        

        conn.commit()
        conn.close()    
    

        

class q6(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="movie list order by biuld date", font=LARGE_FONT)
        label.grid(row=1, column=1,pady=0,padx=500)
        
        button1 = tk.Button(self,height = 1, width = 20, text="Back to Query Page",
                            command=lambda: controller.show_frame(query))
        button1.grid(row=3, column=1,pady=0,padx=1)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()

    
        c.execute("select film_name,biuld_date from film order by biuld_date desc" )
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])
    
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1
            
            print_rows = print_rows + "\n"
        
    
        query_label = tk.Label(self, text=print_rows)
        query_label.grid(row=2, column=1,columnspan=2)


        conn.commit()
        conn.close()

        


class q7(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="number of ticket reserved of a session in a cinema", font=LARGE_FONT)
        label.grid(row=1, column=1,pady=0,padx=1)

        button1 = tk.Button(self,height = 1, width = 20, text="Back to Query Page",
                            command=lambda: controller.show_frame(query))
        button1.grid(row=4, column=2,pady=0,padx=1)

        Q2_btn = tk.Button(self,height = 1, width = 50 , text="show number of ticket reserved of a session in a cinema",command=self.Q2)
        Q2_btn.grid(row=3,column=2,columnspan=2,pady=20,padx=10,ipadx=13)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()

        self.movie_field = tk.Entry(self, width=30)
        self.movie_field.grid(row=3, column=1, padx=20)
        self.movie_field_label = tk.Label(self, text = "Enter Your Session Number")
        self.movie_field_label.grid(row=3, column=0)

        self.movie1_field = tk.Entry(self, width=30)
        self.movie1_field.grid(row=4, column=1, padx=20)
        self.movie1_field_label = tk.Label(self, text = "Enter Your Cinema Name")
        self.movie1_field_label.grid(row=4, column=0)

        conn.commit()
        conn.close() 

    def Q2(self):

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()
        
        movieF = self.movie_field.get()
        movie1F = self.movie1_field.get()
        
        c.execute("select cinema_name,rsession_id,count(*) from get_ticket_session(" + movieF + ",'" + movie1F + "') group by (cinema_name,rsession_id) order by count(*) desc; " )
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])
    
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1
            
            print_rows = print_rows + "\n"
        
    
        query_label = tk.Label(self, text=print_rows)
        query_label.grid(row=13, column=0,columnspan=2)

        query_label.after(10000 , lambda: query_label.destroy())
    
        

        conn.commit()
        conn.close()    
    

        
        

class q8(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="user names order by tikcet buying", font=LARGE_FONT)
        label.grid(row=1, column=1,pady=0,padx=500)
        
        button1 = tk.Button(self,height = 1, width = 20, text="Back to Query Page",
                            command=lambda: controller.show_frame(query))
        button1.grid(row=3, column=1,pady=0,padx=1)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()

    
        c.execute("select registered_id,registered_user,count(reserved_ticket_id) from   registered  join reserved_ticket on(registered_id = user_id) where registered_id in (select user_id from userr) group by (registered_id,registered_user) order by count(reserved_ticket_id) desc" )
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])
    
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1
            
            print_rows = print_rows + "\n"
        
    
        query_label = tk.Label(self, text=print_rows)
        query_label.grid(row=2, column=1,columnspan=2)


        conn.commit()
        conn.close()



class q9(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="director list with their movies", font=LARGE_FONT)
        label.grid(row=1, column=1,pady=0,padx=500)
        
        button1 = tk.Button(self,height = 1, width = 20, text="Back to Query Page",
                            command=lambda: controller.show_frame(query))
        button1.grid(row=3, column=1,pady=0,padx=1)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()

    
        c.execute("select director_id,director_name,codirector_name,film_name from director natural join film order by director_id" )
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])
    
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1
            
            print_rows = print_rows + "\n"
        
    
        query_label = tk.Label(self, text=print_rows)
        query_label.grid(row=2, column=1,columnspan=2)


        conn.commit()
        conn.close()


class q10(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="most tikcet sold by admins", font=LARGE_FONT)
        label.grid(row=1, column=1,pady=0,padx=500)
        
        button1 = tk.Button(self,height = 1, width = 20, text="Back to Query Page",
                            command=lambda: controller.show_frame(query))
        button1.grid(row=3, column=1,pady=0,padx=1)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()

    
        c.execute("select registered_id,registered_user,count(*) from registered join ticket on(admin_id=registered_id) group by (registered_id) order by count(*) desc" )
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])
    
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1
            
            print_rows = print_rows + "\n"
        
    
        query_label = tk.Label(self, text=print_rows)
        query_label.grid(row=2, column=1,columnspan=2)


        conn.commit()
        conn.close()


        
class q11(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="ticket numbers of a session", font=LARGE_FONT)
        label.grid(row=1, column=1,pady=0,padx=1)

        button1 = tk.Button(self,height = 1, width = 20, text="Back to Query Page",
                            command=lambda: controller.show_frame(query))
        button1.grid(row=4, column=2,pady=0,padx=1)

        Q2_btn = tk.Button(self,height = 1, width = 35 , text="show ticket numbers of a session",command=self.Q2)
        Q2_btn.grid(row=3,column=2,columnspan=2,pady=20,padx=10,ipadx=13)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()

        self.movie_field = tk.Entry(self, width=30)
        self.movie_field.grid(row=3, column=1, padx=20)
        self.movie_field_label = tk.Label(self, text = "Enter Your Session Number")
        self.movie_field_label.grid(row=3, column=0)

        self.movie1_field = tk.Entry(self, width=30)
        self.movie1_field.grid(row=4, column=1, padx=20)
        self.movie1_field_label = tk.Label(self, text = "Enter Your Cinema Name")
        self.movie1_field_label.grid(row=4, column=0)

        conn.commit()
        conn.close() 

    def Q2(self):

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()
        
        movieF = self.movie_field.get()
        movie1F = self.movie1_field.get()
        
        c.execute("select cinema_name,session_id,count(*) from get_ticket_session_all(" + movieF + ",'" + movie1F + "') group by (cinema_name,session_id) order by count(*) desc; " )
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])
    
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1
            
            print_rows = print_rows + "\n"
        
    
        query_label = tk.Label(self, text=print_rows)
        query_label.grid(row=13, column=0,columnspan=2)

        
        query_label.after(10000 , lambda: query_label.destroy())
        

        conn.commit()
        conn.close()    
    

class q12(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="most sold movie of all time", font=LARGE_FONT)
        label.grid(row=1, column=1,pady=0,padx=500)
        
        button1 = tk.Button(self,height = 1, width = 20, text="Back to Query Page",
                            command=lambda: controller.show_frame(query))
        button1.grid(row=3, column=1,pady=0,padx=1)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()

    
        c.execute("select film_id,film_name,count(*) from film join reserved_ticket on (film_id=rfilm_id) group by film_id order by count(*) desc" )
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])
    
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1
            
            print_rows = print_rows + "\n"
        
    
        query_label = tk.Label(self, text=print_rows)
        query_label.grid(row=2, column=1,columnspan=2)


        conn.commit()
        conn.close()



class q13(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="most working actors", font=LARGE_FONT)
        label.grid(row=1, column=1,pady=0,padx=500)
        
        button1 = tk.Button(self,height = 1, width = 20, text="Back to Query Page",
                            command=lambda: controller.show_frame(query))
        button1.grid(row=3, column=1,pady=0,padx=1)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()

    
        c.execute("select actor_id,actor_name,count(*) from actor natural join film_actor group by actor_id order by count(*) desc" )
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])
    
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1
            
            print_rows = print_rows + "\n"
        
    
        query_label = tk.Label(self, text=print_rows)
        query_label.grid(row=2, column=1,columnspan=2)


        conn.commit()
        conn.close()

        

        
class q14(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="list of all sessions of a cinema", font=LARGE_FONT)
        label.grid(row=1, column=1,pady=0,padx=1)

        button1 = tk.Button(self,height = 1, width = 20, text="Back to Query Page",
                            command=lambda: controller.show_frame(query))
        button1.grid(row=4, column=2,pady=0,padx=1)

        Q2_btn = tk.Button(self,height = 1, width = 35 , text="show list of all sessions of a cinema",command=self.Q2)
        Q2_btn.grid(row=3,column=2,columnspan=2,pady=20,padx=10,ipadx=13)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()

        self.movie_field = tk.Entry(self, width=30)
        self.movie_field.grid(row=3, column=1, padx=20)
        self.movie_field_label = tk.Label(self, text = "Enter Your Cinema Name")
        self.movie_field_label.grid(row=3, column=0)


        conn.commit()
        conn.close() 

    def Q2(self):

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()
        
        movieF = self.movie_field.get()
        
        
        c.execute("select cinema_name,session_id,session_start_time,session_finish_time,session_language from get_cinema_session('" + movieF + "'); " )
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])
    
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1
            
            print_rows = print_rows + "\n"
        
    
        query_label = tk.Label(self, text=print_rows)
        query_label.grid(row=13, column=0,columnspan=2)

        query_label.after(10000 , lambda: query_label.destroy())
    
        

        conn.commit()
        conn.close()
        

class q15(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="directors ranking", font=LARGE_FONT)
        label.grid(row=1, column=1,pady=0,padx=500)
        
        button1 = tk.Button(self,height = 1, width = 20, text="Back to Query Page",
                            command=lambda: controller.show_frame(query))
        button1.grid(row=3, column=1,pady=0,padx=1)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()

    
        c.execute("select director_id,director_name,director_point_100 from director order by director_point_100 desc" )
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])
    
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1
            
            print_rows = print_rows + "\n"
        
    
        query_label = tk.Label(self, text=print_rows)
        query_label.grid(row=2, column=1,columnspan=2)


        conn.commit()
        conn.close()

        
      
class q17(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="actor edit history", font=LARGE_FONT)
        label.grid(row=1, column=1,pady=0,padx=500)
        
        button1 = tk.Button(self,height = 1, width = 20, text="Back to Query Page",
                            command=lambda: controller.show_frame(query))
        button1.grid(row=3, column=1,pady=0,padx=1)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()

    
        c.execute("select * from actor_edits" )
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])
    
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1
            
            print_rows = print_rows + "\n"
        
    
        query_label = tk.Label(self, text=print_rows)
        query_label.grid(row=2, column=1,columnspan=2)


        conn.commit()
        conn.close()


      
class q18(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = tk.Label(self, text="director edit history", font=LARGE_FONT)
        label.grid(row=1, column=1,pady=0,padx=500)
        
        button1 = tk.Button(self,height = 1, width = 20, text="Back to Query Page",
                            command=lambda: controller.show_frame(query))
        button1.grid(row=3, column=1,pady=0,padx=1)

        conn = psycopg2.connect("dbname=Project user=postgres password=db123 host=localhost")

        c = conn.cursor()

    
        c.execute("select * from director_edits" )
        rows = c.fetchall()
        print_rows = ""
        col_names = []
        for elt in c.description:
            col_names.append(elt[0])
    
        for row in rows:
            flag_column = 0
            for item in row:
                print_rows = print_rows + " / " + col_names[flag_column] + ": " + str(item)
                flag_column += 1
            
            print_rows = print_rows + "\n"
        
    
        query_label = tk.Label(self, text=print_rows)
        query_label.grid(row=2, column=1,columnspan=2)


        conn.commit()
        conn.close()
        

app = SeaofBTCapp()
app.mainloop()
