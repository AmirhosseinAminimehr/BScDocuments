# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random
import util

from game import Agent
from ghostAgents import GHOST_AGENT_MAX_DEPTH, GhostAgent


def scoreEvaluationFunction(currentGameState):
    """
      This default evaluation function just returns the score of the state.
      The score is the same one displayed in the Pacman GUI.

      This evaluation function is meant for use with adversarial search agents
      (not reflex agents).
    """
    return currentGameState.getScore()


class AdversarialSearchAgent(Agent):
    """
      This class provides some common elements to all of your
      multi-agent searchers.  Any methods defined here will be available
      to the MinimaxAgent, SmartPacmanAgent, SmartGhostAgent

      You *do not* need to make any changes here, but you can if you want to
      add functionality to all your adversarial search agents.  Please do not
      remove anything, however.

      Note: this is an abstract class: one that should not be instantiated.  It's
      only partially specified, and designed to be extended.  Agent (game.py)
      is another abstract class.
    """

    def __init__(self, evalFn='scoreEvaluationFunction', depth='2'):
        self.index = 0 # index should be 0 by default
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)


    def getOpponentIndex(self):
        return 1 - self.index


class MinimaxAgent(AdversarialSearchAgent):

    def getAction(self, gameState):
        """
        The Agent will receive a GameState and
        must return an action from Directions.{North, South, East, West, Stop}
        """
        minimaxScores = []
        legalActions = gameState.getLegalActions(self.index)
        for action in legalActions:
            score = self.minimax(
                gameState.generateSuccessor(self.index, action),
                self.getOpponentIndex(),
                0
            )
            minimaxScores.append((score, action))

        bestAction = max(minimaxScores)[1]

        return bestAction

    def minimax(self, gameState, maximizingAgent, currentDepth):

        if self.depth == currentDepth or len(gameState.getLegalActions(maximizingAgent)) == 0:
            return self.evaluationFunction(gameState)

        if self.index == maximizingAgent:
            return self.mmax(gameState, maximizingAgent, currentDepth)

        elif self.getOpponentIndex() ==  maximizingAgent:
            return self.mmin(gameState, maximizingAgent, currentDepth)



    def mmax(self,gameState,maximizingAgent,currentDepth):
        currentDepth = currentDepth + 1
        inf = float('inf')
        v1 = -inf
        for i in gameState.getLegalActions(maximizingAgent):
            v1 =  max(v1,self.minimax(gameState.generateSuccessor(maximizingAgent,i),self.getOpponentIndex(),currentDepth))
        return v1

    def mmin(self,gameState,maximizingAgent,currentDepth):
        currentDepth = currentDepth + 1
        inf = float('inf')
        v2 = inf
        for i in gameState.getLegalActions(maximizingAgent):
            v2 =  min(v2,self.minimax(gameState.generateSuccessor(maximizingAgent,i),self.index,currentDepth))
        return v2











class SmartPacmanAgent(MinimaxAgent):
    def __init__(self, depth='2'):
        self.index = 0
        self.depth = int(depth)
        self.mydepth = 0;

    @staticmethod
    def bfs(gameState, pos1, pos2):
        disL = {}
        disL[pos2] = 0
        dis = 0
        q = util.Queue()
        q.push(pos2)
        if gameState.getGhostState(1).scaredTimer:
            dis = util.manhattanDistance(pos1, pos2)
            return dis
        if gameState.getNumAgents() == 3:
            if gameState.getGhostState(2).scaredTimer:
                dis = util.manhattanDistance(pos1, pos2)
                return dis
        seen = []
        walls = gameState.getWalls().asList()
        while not q.isEmpty():
            position = q.pop()
            if pos1 == position:
                dis = disL [position]
                break
            new_pos = (position[0], position[1] - 1)
            if new_pos not in walls and new_pos not in seen:
                q.push(new_pos)
                seen.append(new_pos)
                disL[new_pos] =disL[position] + 1

            new_pos = (position[0], position[1] + 1)
            if new_pos not in walls and new_pos not in seen:
                q.push(new_pos)
                seen.append(new_pos)
                disL[new_pos] = disL[position] + 1
            new_pos = (position[0] - 1, position[1])
            if new_pos not in walls and new_pos not in seen:
                q.push(new_pos)
                seen.append(new_pos)
                disL[new_pos] = disL[position] + 1

            new_pos = (position[0] + 1, position[1])
            if new_pos not in walls and new_pos not in seen:
                q.push(new_pos)
                seen.append(new_pos)
                disL[new_pos] = disL[position] + 1



        return dis

    def evaluationFunction(self,gameState):

        score = gameState.getScore()
        pacman_Pos = gameState.getPacmanPosition()
        ghost_Pos = gameState.getGhostPosition(1)
        foods_PosList = gameState.getFood().asList()
        food_Num = len(foods_PosList)
        rand = 0
        if rand == 0:
            rand = 1
        else :
            rand = 0
        min = 99999999999
        for i in foods_PosList:
            if self.bfs(gameState,pacman_Pos,i) < min:
                min = self.bfs(gameState,pacman_Pos,i)
        if min ==  99999999999 :
            min = 1
        print(min)
        print(100 * food_Num)
        pacman_Dis_Ghost = self.bfs(gameState,pacman_Pos,ghost_Pos)
        print(pacman_Dis_Ghost)
        if food_Num > 5 :
            if pacman_Dis_Ghost < 3 :
                score = score +  pacman_Dis_Ghost
            if rand != 0:
                score = score - 100 * food_Num

            score = score - min
        else :
            score = score -  min




        return score
        # gameState.
        """
        Returns evaluation score for each gameState

        Args:
            gameState: an instance of pacman.GameState

        Returns:
            Return the evaluation score
        """
        util.raiseNotDefined()


class SmartGhostAgent(MinimaxAgent):
    def __init__(self, index):
        self.index = 1
        self.depth = GHOST_AGENT_MAX_DEPTH

    @staticmethod
    def evaluationFunction(gameState):
        """
        Similar to SmartPacmanAgent
        """

        pacmanPos = gameState.getPacmanPosition()
        score = gameState.getScore()
        legal_act = gameState.getLegalActions()
        foods_PosList = gameState.getFood().asList()
        food_Num = len(foods_PosList)
        max = -9999999999
        for i in legal_act :
            if gameState.generateSuccessor(0,i).getScore() < max :
                max = gameState.generateSuccessor(0,i).getScore()
                maxPos = Actions.directionToVector(i)
                pacmanPos = pacmanPos + maxPos
        max1 = -9999999999
        for i in legal_act :
            if gameState.generateSuccessor(0,i).getScore() < max1 :
                max1 = gameState.generateSuccessor(0,i).getScore()
                maxPos1 = Actions.directionToVector(i)
                pacmanPos = pacmanPos + maxPos1
        max2 = -9999999999
        for i in legal_act :
            if gameState.generateSuccessor(0,i).getScore() < max2 :
                max2 = gameState.generateSuccessor(0,i).getScore()
                maxPos2 = Actions.directionToVector(i)
                pacmanPos = pacmanPos + maxPos2
        max3 = -9999999999
        for i in legal_act :
            if gameState.generateSuccessor(0,i).getScore() < max3 :
                max3 = gameState.generateSuccessor(0,i).getScore()
                maxPos3 = Actions.directionToVector(i)
                pacmanPos = pacmanPos + maxPos3

        ghost_Pos = gameState.getGhostPosition(1)
        pacman_Dis_Ghost = manhattanDistance((pacmanPos[0]-1,pacmanPos[1]),ghost_Pos)
        score = - pacman_Dis_Ghost

        return score

class SuperGhostAgent(GhostAgent):
    def __init__(self, index):
        self.index = index
        self.depth = GHOST_AGENT_MAX_DEPTH


    def getAction(self, gameState):
        """
        The Agent will receive a GameState and
        must return an action from Directions.{North, South, East, West, Stop}
        """
        minimaxScores = []
        legalActions = gameState.getLegalActions(self.index)
        for action in legalActions:
            score = self.minimax(
                gameState.generateSuccessor(self.index, action),
                0,
                0
            )
            minimaxScores.append((score, action))

        bestAction = max(minimaxScores)[1]

        return bestAction

    def minimax(self, gameState, maximizingAgent, currentDepth):

        if self.depth == currentDepth or len(gameState.getLegalActions(maximizingAgent)) == 0:
            return self.evaluationFunction(gameState)

        if self.index == maximizingAgent:
            return self.mmax(gameState, maximizingAgent, currentDepth)

        elif 0 ==  maximizingAgent:
            return self.mmin(gameState, maximizingAgent, currentDepth)



    def mmax(self,gameState,maximizingAgent,currentDepth):
        currentDepth = currentDepth + 1
        inf = float('inf')
        v1 = -inf
        for i in gameState.getLegalActions(maximizingAgent):
            v1 =  max(v1,self.minimax(gameState.generateSuccessor(maximizingAgent,i),0,currentDepth))
        return v1

    def mmin(self,gameState,maximizingAgent,currentDepth):
        currentDepth = currentDepth + 1
        inf = float('inf')
        v2 = inf
        for i in gameState.getLegalActions(maximizingAgent):
            v2 =  min(v2,self.minimax(gameState.generateSuccessor(maximizingAgent,i),self.index,currentDepth))
        return v2
    def evaluationFunction(self,gameState):
        """
        Similar to SmartPacmanAgent
        """

        pacmanPos = gameState.getPacmanPosition()
        score = gameState.getScore()
        legal_act = gameState.getLegalActions()
        foods_PosList = gameState.getFood().asList()
        food_Num = len(foods_PosList)
        max = -9999999999
        for i in legal_act :
            if gameState.generateSuccessor(0,i).getScore() < max :
                max = gameState.generateSuccessor(0,i).getScore()
                maxPos = Actions.directionToVector(i)
                pacmanPos = pacmanPos + maxPos

        ghost_Pos = gameState.getGhostPosition(self.index)
        pacman_Dis_Ghost = manhattanDistance((pacmanPos[0]-1,pacmanPos[1]),ghost_Pos)
        score = - pacman_Dis_Ghost

        return score
