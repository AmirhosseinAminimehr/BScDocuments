import numpy as np
from ple import PLE
from ple.games.pixelcopter import Pixelcopter


class Agent(object):
	"""
	The Bot class that applies the Qlearning logic to Flappy bird game
	After every iteration (iteration = 1 game that ends with the bird dying) updates Q values
	After every DUMPING_N iterations, dumps the Q values to the local JSON file
	"""

	def __init__(self):
		self.gameCNT = 0
		self.DUMPING_N = 75
		self.discount = 1
		self.r = [1, -100]
		self.alpha = 0.65
		self.last_state = "0_120_40_80_200"
		self.last_action = 0
		self.moves = []
		self.actions = [119,None]
		self.agent = Pixelcopter(width=256, height=256)
		print self.alpha
		print len(self.qvalues)


	def act(self, player_vel, player_y, ceil,floor,next_gate):
		"""
		Chooses the best action with respect to the current state - Chooses 0 (don't flap) to tie-break
		"""
		state = self.map_state(player_vel, player_y, ceil,floor,next_gate)

		self.moves.append(
			(self.last_state, self.last_action, state)
		)  # Add the experience to the history

		self.last_state = state  # Update the last_state with the current state
		if self.qvalues.get(state) == None:
			self.qvalues[state] = [0,0]

		if self.qvalues[state][0] > self.qvalues[state][1]:
			self.last_action = 0
			return self.actions[0]
		else:
			self.last_action = 1
			return self.actions[1]

	def update_scores(self, dump_qvalues = True):
		"""
		Update qvalues via iterating over experiences
		"""
		history = list(reversed(self.moves))
		loss = True
		
		game_state = self.getGameState()
		for exp in history:
			state = exp[0]
			state_vals = list(map(int,state.split("_")))
			act = exp[1]
			res_state = exp[2]
			res_state_vals = list(map(int,res_state.split("_")))

			if loss:
				if res_state_vals[0] < -5:
					cur_reward = -200
				else:
					cur_reward = self.r[1]
				loss = False
			else:
				cur_reward = self.r[0]


			self.qvalues[state][act] = (1-self.alpha) * (self.qvalues[state][act]) + \
									   self.alpha * ( cur_reward + self.discount*max(self.qvalues[res_state]) )

		self.gameCNT += 1
		if self.gameCNT % 10 == 0:
			self.alpha -= 0.00005
		if self.alpha < 0.05:
			self.alpha = 0.05
		self.qvalues['alpha'] = self.alpha
		self.moves = []

	def map_state(self, player_vel, player_y, ceil,floor,next_gate):


		player_vel = int(player_vel)
		player_y = int(player_y) - int(player_y) % 10
		ceil = int(ceil) - int(ceil) % 10
		floor = int(floor) - int(floor) % 10
		next_gate = int(next_gate) - int(next_gate) % 20



		return str(int(player_vel)) + "_" + str(int(player_y)) + "_" + str(int(ceil))\
		 + "_" + str(int(floor)) + "_" + str(int(next_gate))


	def getGameState(self):
		return self.agent.getGameState()

ai = Agent()

env = PLE(ai.agent, fps=30, force_fps=False, display_screen=True)
env.init()
while True:
	if env.game_over():
		ai.update_scores()
		env.reset_game()

	state = ai.getGameState()
	params = (state['player_vel'], state['player_y'], state['player_dist_to_ceil'], \
		state['player_dist_to_floor'], state['next_gate_dist_to_player'])
	env.act(ai.act(*params))
