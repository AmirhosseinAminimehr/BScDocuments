import util
import ast

from game import Directions

UNREACHABLE_GOAL_STATE = [Directions.STOP]


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    s = Directions.SOUTH
    w = Directions.WEST

    nextPos = problem.getNextStates((5,5))
    return [s, s, w, s, w, w, s, w]

def getKeysByValue(dictOfElements, valueToFind):
    listOfKeys = list()
    listOfItems = dictOfElements.items()
    for item  in listOfItems:
        if item[1] == valueToFind:
            listOfKeys.append(item[0])
    return  listOfKeys


def right_hand_maze_search(problem):
    """
    Q1: Search using right hand rule

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's next states:", problem.getNextStates(problem.getStartState())

    :param problem: instance of SearchProblem
    :return: list of actions
    """

    "*** YOUR CODE HERE ***"
    j = Directions.SOUTH
    ch = Directions.WEST
    r = Directions.EAST
    sh = Directions.NORTH

    startPos = list(problem.getStartState())
    nextPos = problem.getNextStates(tuple(startPos))
    directionAdd = []
    currentDir = "NORTH"

    while(problem.isGoalState(tuple(startPos)) != True):
        if currentDir == "WEST" :
            if "North" in [i[1] for i in nextPos]:
                startPos[1] = startPos[1] + 1
                directionAdd.append(sh)
                currentDir = "NOURTH"
                nextPos = problem.getNextStates(tuple(startPos))
            elif "West" in [i[1] for i in nextPos]:
                startPos[0] = startPos[0] - 1
                directionAdd.append(ch)
                currentDir = "WEST"
                nextPos = problem.getNextStates(tuple(startPos))
            elif "South" in [i[1] for i in nextPos]:
                startPos[1] = startPos[1] - 1
                directionAdd.append(j)
                currentDir = "SOUTH"
                nextPos = problem.getNextStates(tuple(startPos))
            else :
                startPos[0] = startPos[0] + 1
                directionAdd.append(r)
                currentDir = "EAST"
                nextPos = problem.getNextStates(tuple(startPos))

        elif currentDir == "SOUTH" :
            if "West" in [i[1] for i in nextPos]:
                 startPos[0] = startPos[0] - 1
                 directionAdd.append(ch)
                 currentDir = "WEST"
                 nextPos = problem.getNextStates(tuple(startPos))
            elif "South" in [i[1] for i in nextPos]:
                startPos[1] = startPos[1] -1
                directionAdd.append(j)
                nextPos = problem.getNextStates(tuple(startPos))
            elif "East" in [i[1] for i in nextPos]:
                startPos[0] = startPos[0] + 1
                directionAdd.append(r)
                currentDir = "EAST"
                nextPos = problem.getNextStates(tuple(startPos))
            else:
                startPos[1] = startPos[1] + 1
                directionAdd.append(sh)
                currentDir = "NORTH"
                nextPos = problem.getNextStates(tuple(startPos))

        elif currentDir == "EAST" :
            if "South" in [i[1] for i in nextPos]:
                startPos[1] = startPos[1] -1
                directionAdd.append(j)
                currentDir = "SOUTH"
                nextPos = problem.getNextStates(tuple(startPos))

            elif "East" in [i[1] for i in nextPos]:
                startPos[0] = startPos[0] + 1
                directionAdd.append(r)
                nextPos = problem.getNextStates(tuple(startPos))
            elif "North" in [i[1] for i in nextPos]:
                startPos[1] = startPos[1] + 1
                directionAdd.append(sh)
                currentDir = "NORTH"
                nextPos = problem.getNextStates(tuple(startPos))
            else:
                 startPos[0] = startPos[0] - 1
                 directionAdd.append(ch)
                 currentDir = "WEST"
                 nextPos = problem.getNextStates(tuple(startPos))
        else :
            if "East" in [i[1] for i in nextPos]:
                startPos[0] = startPos[0] + 1
                directionAdd.append(r)
                currentDir = "EAST"
                nextPos = problem.getNextStates(tuple(startPos))
            elif "North" in [i[1] for i in nextPos]:
                startPos[1] = startPos[1] + 1
                directionAdd.append(sh)
                currentDir = "NORTH"
                nextPos = problem.getNextStates(tuple(startPos))
            elif "West" in [i[1] for i in nextPos]:
                startPos[0] = startPos[0] - 1
                directionAdd.append(ch)
                currentDir = "WEST"
                nextPos = problem.getNextStates(tuple(startPos))
            else:
                startPos[1] = startPos[1] -1
                directionAdd.append(j)
                currentDir = "SOUTH"
                nextPos = problem.getNextStates(tuple(startPos))

    return directionAdd


def dfs(problem):

    """
    Q2: Search the deepest nodes in the search tree first.
    """

    "*** YOUR CODE HERE ***"

    print("lopo")
    NState = problem.getStartState()
    if len(problem.getNextStates(NState)) == 0:
        return [Directions.STOP]
    visitedList = set()
    visitedList.add(problem.getStartState())
    states = util.Stack()
    stateTuple = (problem.getStartState(), [])
    states.push(stateTuple)
    while problem.isGoalState(NState) != True:
        if states.isEmpty() == True:
            return [Directions.STOP]
        state, dirList = states.pop()
        visitedList.add(state)
        for i in problem.getNextStates(state):
            if i[0] not in visitedList:
                lastDir = i[1]
                NState = i[0]
                states.push((i[0], dirList + [i[1]]))
    else:
        LastdirList = dirList + [lastDir]

    return LastdirList



def bfs(problem):
    """
    Q3: Search the shallowest nodes in the search tree first.
    """

    "*** YOUR CODE HERE ***"
    visitedList = set()
    visitedList.add(problem.getStartState())
    states = util.Queue()
    states.push((problem.getStartState(), []))
    while states.isEmpty() != True :
        state, dirList = states.pop()
        if problem.isGoalState(state) == True:
            return dirList
        for i in problem.getNextStates(state):
            if i[0] not in visitedList:
                visitedList.add(i[0])
                states.push((i[0], dirList + [i[1]]))
    else:
        return [Directions.STOP]
        
    return dirList



def ucs(problem):
    """
    Q6: Search the node of least total cost first.
    """

    "*** YOUR CODE HERE ***"
    states = util.PriorityQueue()
    visitedList = set()
    states.push((problem.getStartState(), [] , 0) ,0)
    while states.isEmpty() == False:
        state, dirList ,cost= states.pop()
        if problem.isGoalState(state) == True:
            return dirList
        if state not in visitedList:
            for StateNext in problem.getNextStates(state):
                if StateNext[0] not in visitedList:
                    newCost = cost + problem.cost_function(StateNext[0])
                    states.push((StateNext[0], dirList + [StateNext[1]],newCost), newCost)
        visitedList.add(state)
    else :
        return [Directions.STOP]

    return dirList
